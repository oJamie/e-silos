$('document').ready(function (){
 
//    $('#username').empty(function (){
//      $(this).popover({
//          content: "Invalid"
//        });
//    });
//    $('#username')
    
//    $('#contact_email').on('input', function() {
//	var input=$(this);
//	var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
//	var is_email=re.test(input.val());
//	if(is_email){input.removeClass("invalid").addClass("valid");}
//	else{input.removeClass("valid").addClass("invalid");}
//    });
//    
//    $('#contact_message').keyup(function(event) {
//	var input=$(this);
//	var message=$(this).val();
//	alert(message);
//	if(message){input.removeClass("invalid").addClass("valid");}
//	else{input.removeClass("valid").addClass("invalid");}	
//    });
//    
//    // Name can't be blank
//    $('#contact_name').on('input', function() {
//            var input=$(this);
//            var is_name=input.val();
//            if(is_name){input.removeClass("invalid").addClass("valid");}
//            else{input.removeClass("valid").addClass("invalid");}
//    });
//    
//    
});

