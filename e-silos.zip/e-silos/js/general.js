// JavaScript Document
function editAds(x){
	window.location = 'edit_hostel.php?p=' + x;
}

function deleteAds(x){
	var ans = confirm('Deleting this ad cannot be undone!');
	if(ans == 1){
		$.post("delete.php",{
			id: x
			},function(data){
			alert(data);
			window.location = 'myads.php';
		});
	}
}

function changeImages(x){
	$('#' + x).click();
}

function deleteImage(x){
	$.post("delete_image.php",{
			id: x
			},function(data){
			window.location.reload();
		});
}

function onImageChange(x,event){
	var fp = URL.createObjectURL(event.target.files[0]);
	$('#' + x).attr('src',fp);
}

function changeImage(x){
	document.getElementById("img").src = "images/" + x;
}

function addToHostelFav(x){
	$.post("create_fav.php",{
			id: x,
			cat: 'hostel'
			},function(data){
			switch(data){
				case 'success':
					alert('Ad has been added to favorite!');
				break;
				case 'failed':
					alert('Cant add to favorite,check connection!');
				break;
				case 'login':
					alert('You need to login first!');
					window.location = 'index2.php';
				break;
				default: alert('You need to login first!');
						 window.location = 'index2.php';
				break;
			}
		});
}

function addToRoommateFav(x){
	$.post("create_fav.php",{
			id: x,
			cat: 'roommate'
			},function(data){
			switch(data){
				case "success":
				alert('Ad has been added to favorite!');
				break;
				case "failed":
				alert('Cant add to favorite,check connection!');
				break;
				case "login":
				alert('You need to login first!');
				window.location = 'index2.php';
				break;
				default: alert('You need to login first!');
						 window.location = 'index2.php';
				break;
			}
		});
}

function addToApartFav(x){
	$.post("create_fav.php",{
			id: x,
			cat: 'apartment'
			},function(data){
			switch(data){
				case "success":
//				alert('Ad has been added to favorite!');
                                 swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Ad has been added to favorite!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
				break;
				case "failed":
//				alert('Cant add to favorite,check connection!');
				 swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Cant add to favorite,check connection!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
                                break;
				case "login":
				alert('You need to login first!');
                                swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "You need to login first!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
				window.location = 'index2.php';
				break;
				default: alert('You need to login first!');
						 window.location = 'index2.php';
				break;
			}
		});
}

function remove(x){
	var ans = confirm('This ad will be removed from your favorite!');
	if(ans == 1){
		$.post("delete_fav.php",{
			id: x
			},function(data){
			alert(data);
			window.location = 'myfav.php';
		});
	}
}



$(document).ready(function(e) {
	
	$("#btnPostAds").click(function(e) {
        window.location = "home.php";
    });
	
	$("#btnVarify").click(function(e) {
        $.post("varify.php",{
			programme: $("#programme").val()
			},function(data){
			if(data === 'Please enter your voters id!'){
				$("#response").html(data).show(0).hide(8000).css("color","#00AB43");
			}else {
				$("#response").html(data).show(6000).hide(1000).css("color","#00AB43");
				window.location = 'home.php';
			}
		});
    });
	
	$.get("get_countries.php",function(data){
		$("#country").html(data);
	});
	
	$("#country").change(function(e) {
        $.post("get_regions.php",{
			country: $(this).val()
			},function(data){
			$("#region").html(data);
		});
    });
	
	$("#region").change(function(e) {
        $.post("get_cities.php",{
			region: $(this).val()
			},function(data){
			$("#city").html(data);
		});
    });
    
	$("#btnJoinUs").click(function(e) {
        var fData = new FormData($("#acc_form")[0]);
		$.ajax({
			url:"create_acc.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
					$("#feedback").show().css({"font-size":"12px","color":"#5CB85C"}).html("Account created successfuly!").fadeOut(4000);
					break;
					case "failed":
					$("#feedback").show().css({"font-size":"12px","color":"#F84144"}).html("Account exist already!").fadeOut(4000);
					break;
					case "missmatch":
					$("#feedback").show().css({"font-size":"12px","color":"#F9A630"}).html("Password does not match,try again!").fadeOut(4000);
					break;
					case "invalid":
					$("#feedback").show().css({"font-size":"12px","color":"#F9A630"}).html("All fields are required!").fadeOut(4000);
					break;
					default:
					$("#feedback").show().css({"font-size":"12px","color":"#F9A630"}).html(data).fadeOut(4000);
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		$("#acc_form").trigger("reset");
    });
	
	$("#btnLogin").click(function(e) {
        var fData = new FormData($("#login_form")[0]);
		$.ajax({
			url:"login_varify.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":window.location = "home.php";
					break;
					case "failed":
					$("#feedback2").show().css({"font-size":"12px","color":"#F84144"}).html("Invalid credentials,try again!").fadeOut(4000);
					break;
					case "invalid":
					$("#feedback2").show().css({"font-size":"12px","color":"#F9A630"}).html("Email and password is required!").fadeOut(4000);
					break;
					default:
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		$("#login_form").trigger("reset");
    });
	
	$("#btnPost").click(function(e) {
        var fData = new FormData($("#post_form1")[0]);
		$.ajax({
			url:"create_market.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
//					alert("Posted successfuly!");
                                        swal({
                                                icon: "success",
//                                                title: "Successful!",
                                                text: "Posted successfuly!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					$("#post_form1").trigger("reset");
					break;
					case "failed":
//					alert("Post failed!");
                                        swal({
                                                icon: "error",
//                                                title: "Error!",
                                                text: "Post failed!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "wrong price":
//					alert("Price must be numeric!");
                                        swal({
                                                icon: "error",
//                                                title: "Error!",
                                                text: "Price must be numeric!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "image error":
					alert("Upload at least one image and images must not be more than 3!");
                                        swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Upload at least one image and images must not be more than 3!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "wrong phone number":
//					alert("Account number must be numeric!");
                                        swal({
                                                icon: "error",
//                                                title: "Error!",
                                                text: "Account number must be numeric!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "invalid":
//					alert("All fields are required!");
                                        swal({
                                                icon: "error",
//                                                title: "Err!",
                                                text: "All fields are required!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					default:
                                            swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "an error occured!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	
	
	$("#btnPostApart").click(function(e) {
        var fData = new FormData($("#post_form2")[0]);
		$.ajax({
			url:"create_apartment.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
					$("#feedback").show().css({"font-size":"15px","color":"#5CB85C"}).html("Posted successfuly!").fadeOut(8000);
					$("#post_form2").trigger("reset");
					break;
					case "failed":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Post failed!").fadeOut(8000);
					break;
					case "wrong price":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Price must be numeric!").fadeOut(8000);
					break;
					case "image error":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Upload at least one image and images must not be more than 3!").fadeOut(8000);
					break;
					case "wrong phone number":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("Phone number must be numeric!").fadeOut(8000);
					break;
					case "invalid":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("All fields are required!").fadeOut(8000);
					break;
					default: swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "an error occured!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	$("#btnUpdateApart").click(function(e) {
        var fData = new FormData($("#post_form2")[0]);
		$.ajax({
			url:"update_apartment.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
					$("#feedback").show().css({"font-size":"15px","color":"#5CB85C"}).html("Updated successfuly!").fadeOut(8000);
					$("#post_form2").trigger("reset");
					break;
					case "failed":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Update failed!").fadeOut(8000);
					break;
					case "wrong price":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Price must be numeric!").fadeOut(8000);
					break;
					case "image error":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Upload at least one image and images must not be more than 3!").fadeOut(8000);
					break;
					case "wrong phone number":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("Phone number must be numeric!").fadeOut(8000);
					break;
					case "invalid":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("All fields are required!").fadeOut(8000);
					break;
					default:
                                            swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "an error occured!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	$("#btnPostRoom").click(function(e) {
        var fData = new FormData($("#post_form3")[0]);
		$.ajax({
			url:"create_roommate.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
					$("#feedback").show().css({"font-size":"15px","color":"#5CB85C"}).html("Posted successfuly!").fadeOut(8000);
					$("#post_form3").trigger("reset");
					break;
					case "failed":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Post failed!").fadeOut(8000);
					break;
					case "image error":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Upload at least one image and images must not be more than 3!").fadeOut(8000);
					break;
					case "wrong phone number":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("Phone number must be numeric!").fadeOut(8000);
					break;
					case "invalid":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("All fields are required!").fadeOut(8000);
					break;
					default: 
//                                            alert("an error occured!");
                                        swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "an error occured!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	$("#btnUpdateRoom").click(function(e) {
        var fData = new FormData($("#post_form3")[0]);
		$.ajax({
			url:"update_roommate.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
					$("#feedback").show().css({"font-size":"15px","color":"#5CB85C"}).html("Updated successfuly!").fadeOut(8000);
					$("#post_form3").trigger("reset");
					break;
					case "failed":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Update failed!").fadeOut(8000);
					break;
					case "image error":
					$("#feedback").show().css({"font-size":"15px","color":"#F84144"}).html("Upload at least one image and images must not be more than 3!").fadeOut(8000);
					break;
					case "wrong phone number":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("Phone number must be numeric!").fadeOut(8000);
					break;
					case "invalid":
					$("#feedback").show().css({"font-size":"15px","color":"#F9A630"}).html("All fields are required!").fadeOut(8000);
					break;
					default: 
//                                            alert("an error occured!");
                                            swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "an error occured!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
                                        break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	$("#btnUpdate2").click(function(e) {
        var fData = new FormData($("#post_form1")[0]);
		$.ajax({
			url:"update_hostel.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				switch(data){
					case "success":
                                            swal({
                                                icon: "success",
//                                                title: "Successful!",
                                                text: "Updated successfuly!",
                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
//					alert("");
					$("#post_form1").trigger("reset");
					break;
					case "failed":
					swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Updated Failed!",
                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "wrong price":
//					alert("");
                                        swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Price must be numeric!!",
                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "image error":
//					alert("");
                                        swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Upload at least one image and images must not be more than 3!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                              });
					break;
					case "wrong phone number":
//					alert("Phone number must be numeric!");
                                        swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "Phone number must be numeric!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                        });
					break;
					case "invalid":
//					alert("All fields are required!");
					swal({
                                                icon: "error",
//                                                title: "Successful!",
                                                text: "All fields are required!",
//                                                timer: "4000",
                                                showConfirmButton: true,
                                                confirmButtonText: "Okay",
                                                closeOnConfirm: false
                                        });
                                        break;
					default:
					break;
				}
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
		window.scrollTo(0,0);
    });
	
	
	$("#btnUpdatePhotos").click(function(e) {
        var fData = new FormData($("#form_m")[0]);
		$.ajax({
			url:"image_update.php",
			async:false,
			type:"POST",
			data:fData,
			success: function(data){
				if(data == 'image updated successfully!'){
					alert(data);
					window.location.reload();
				}else {
					alert(data);
				}		
			},
			cache:false,
			processData:false,
			contentType:false
		});
		e.preventDefault();
    });
	
});