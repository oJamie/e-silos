$(document).ready(function () {
    
    $(document).on('click', '#register', function () {
        
        var username = $('#username').val();
        var phone = $('#phone').val();
        var password = $('#password').val();
        var con_password = $('#con_password').val();
        var category = $('#category').val();
       
        if (username === "")
        {
            alert("Enter username");
            return false;
        } 
        else if (phone === "")
        {
            alert("Enter Phone");
            return false;
        } 
        else if (password === "")
        {
            alert("Enter Password");
            return false;
        } 
        else if (con_password === "")
        {
            alert("Enter Confirm Password");
            return false;
        } 
        else if (category === "")
        {
            alert("Enter Category ");
            return false;
        } else {
            console.log('i am here!');
            $.ajax({
                url: "controllers/execRegistration.php",
                method: "POST",
                data: {username: username, phone: phone, password: password, category: category, con_password: con_password},
                dataType: "text",
                success: function (data)
                {
                    alert(data); 
//                    if (click(function) == )
                },
                error: function(XMLHttpRequest, data) { 
                    alert("Status: " + data);
                }   
            });
        }
//        e.preventDefault();
    });

//        function fetch_data()
//    {
//        $.ajax({
//            url: "../controllers/execLogin.php",
//            method: "POST",
//            success: function (data) {
//               
//            }
//        });
//    }
//    fetch_data();

});

