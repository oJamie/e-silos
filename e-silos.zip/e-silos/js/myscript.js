
$(document).ready(function () {
    $('#login').click(function () {
        location = 'http://localhost/e-silos/index.php';
        $('#signIn').show(0);
    });
    $('#refreshMail').click(function () {
        location.reload();
    });
    
    
    $('#compose').click(function () {
        $('#sentCont').hide();
        $('#composeCont').show(650);
        $('#inboxCont').hide();
    });

    $('#sentMessage').click(function () {
        $('#sentCont').show(650);
        $('#composeCont').hide();
        $('#inboxCont').hide();
    });
    $('#inbox').click(function () {
        $('#inboxCont').show(650);
        $('#sentCont').hide();
        $('#composeCont').hide();        
    });
    $('input:checkbox').click(function () {
        $('input:checkbox').not(this).prop('checked', false);
    });
    $('#infoBtn').click(function () {
        $('#basicInfo').show();
        $('#pwd').hide();
        $('#reset').hide();
    });
    $('#pwdBtn').click(function () {
        $('#basicInfo').hide();
        $('#reset').hide();
        $('#pwd').show(400);
    });
    $('#resetBtn').click(function () {
        var isConfirm = confirm("Are you sure you want to reset the password? ");
        if (isConfirm == true) {
            swal("Success", "Success Resetting Password", "success");
            $('#basicInfo').hide();
            $('#pwd').hide();
            $('#reset').show(600);
        } else if (isConfirm == false) {
            location.reload();
            swal("Cancelled", "You Cancelled", "error");
        }
    });
    $('#cancel').click(function () {
        swal({
            icon: "warning",
            title: "Warning!",
            text: "Click yes to cancel or No to continue",
            confirmButtonText: "No",
            cancelButtonText: "Yes, Cancel",
            closeOnConfirm: false,
            closeOnCancel: false
        }),
                function (isConfirm) {
                    if (isConfirm) {
                        location = "http://localhost/e-silos/index.php";
                    } else {
                        location.reload();
                    }
                }
    });
    $('#noneBtn').click(function () {
////            Swalalert();
//            alert("Proceeding To welcome Registration  Page");
        swal({
            icon: "warning",
            title: "Redirecting!",
            text: "Proceeding to Home Page",
            timer: "4000",
            showConfirmButton: true,
            confirmButtonText: "Home",
            closeOnConfirm: false
        }).then(function (result) {
            window.location = "http://localhost/e-silos/index.php";
        });
    });
    $('#Btn').click(function () {
//            alert("Proceeding To  Registration  Page");
        swal({
            icon: "warning",
            title: "Redirecting!",
            text: "Proceeding to  Registration Page",
            timer: "4000",
            showConfirmButton: true,
            confirmButtonText: "Home",
            closeOnConfirm: false
        }).then(function (result) {
            $('#firstContent').hide();
            $('#secondContent').toggle(600);
            $('#thirdContent').hide();
        });
    });
    $('#traderBtn').click(function () {
        swal({
            icon: "warning",
            title: "Redirecting!",
            text: "Proceeding to Trader Registration Page",
            timer: "4000",
            showConfirmButton: true,
            confirmButtonText: "Home",
            closeOnConfirm: false
        }).then(function (result) {
            $('#firstContent').hide();
            $('#secondContent').hide();
            $('#thirdContent').toggle(600);
        });
    });
//    $('#').click(function () {
////            window.location = "";
//        swal({
//            icon: "warning",
//            title: "Redirecting!",
//            text: "Proceeding to  Registration Page",
//            timer: "4000",
//            showConfirmButton: true,
//            confirmButtonText: "Home",
//            closeOnConfirm: false
//        }).then(function (result) {
//            $('#firstContent').hide();
//            $('#secondContent').hide();
//            $('#thirdContent').show();
//        });
//    });
    $('#trader').click(function () {
//            window.location = "";
        swal({
            icon: "warning",
            title: "Redirecting!",
            text: "Proceeding to Trader Registration Page",
            timer: "4000",
            showConfirmButton: true,
            confirmButtonText: "Home",
            closeOnConfirm: false
        }).then(function (result) {
            $('#firstContent').hide();
            $('#secondContent').hide();
            $('#thirdContent').show();
        });
    });
    $('#password').keyup(function ()
    {
        $('#result').html(checkStrength($('#password').val()));
    })

    function checkStrength(password)
    {
        var strength = 0

        if (password.length < 6) {
            $('#result').removeClass();
            $('#result').addClass('short');
            return 'Too short'
        }

        if (password.length > 7)
            strength += 1;
        //If password contains both lower and uppercase characters, increase strength value.
        if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/))
            strength += 1;
        //If it has numbers and characters, increase strength value.
        if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/))
            strength += 1;
        //If it has one special character, increase strength value.
        if (password.match(/([!,%,&,@,#,$,^,*,?,_,~])/))
            strength += 1;
        //if it has two special characters, increase strength value.
        if (password.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/))
            strength += 1;
        //Calculated strength value, we can return messages



        //If value is less than 2

        if (strength < 2)
        {
            $('#result').removeClass();
            $('#result').addClass('weak');
            return 'Weak';
        } else if (strength == 2)
        {
            $('#result').removeClass();
            $('#result').addClass('good');
            return 'Good';
        } else
        {
            $('#result').removeClass();
            $('#result').addClass('strong');
            return 'Strong';
        }
    }



    $('#freeTrial').click(function () {
        $.confirm({
            content: 'Are you sure you want to proceed with this option?',
            type: 'orange',
            typeAnimated: true,
            buttons: {
                Action: {
                    text: 'Yes',
                    keys: ['shift', 'alt'],
                    btnClass: 'btn-green',
                    action: function () {
                        var session_container = "$_SESSION['username']";

                        var package_type = 'FREE';
                        var duration = '3 DAYS';
                        var slot = '1';
                        var amount = '0.00';
                        var detail = 'Free Storage Package';
                        var package_code = '47DE987RF';
                        var support = 'YES';
                        var delivery = 'YES';
                        var free_storage = 'YES';
                        var refund = 'NO';
                        var username = session_container;
                        $.ajax({
                            url: "../trader/execInsertStorage.php",
                            method: "POST",
                            data: {package_type: package_type, duration: duration, slot: slot, amount: amount, detail: detail, package_code: package_code, support: support, delivery: delivery, free_storage: free_storage, refund: refund, session_container: username},
                            dataType: "text",
                            success: function (data) {
                                $('#data_body').html(data);
                                window.location = "http://localhost/e-silos/trader/free_storagePlan.php";
                                fetch_storage();
                            }
                        });
                    }
                },
                close: {
                    text: 'Close',
                    btnClass: 'btn-red',
                    keys: ['close'],
                    action: function () {
                    }
                }
            }
        });
    });
    $('#buyNow').click(function () {
        $.confirm({
            content: 'Are you sure you want to proceed with this option?',
            type: 'orange',
            typeAnimated: true,
            buttons: {
                Action: {
                    text: 'Yes',
                    keys: ['shift', 'alt'],
                    btnClass: 'btn-green',
                    action: function () {
                        $.confirm({
                            type: 'green',
                            typeAnimated: true,
                            btnClass: 'btn-green',
                            content: 'Contact the coordinator on <a href="tel:0554228890"> Click me</a>'
                        });
                    }
                },
                close: {
                    text: 'Close',
                    btnClass: 'btn-red',
                    keys: ['close'],
                    action: function () {
                    }
                }
            }
        });
    });



    $('#powerUp').click(function () {
        var redirect = window.location = 'http://localhost/e-silos/trader/buy_storage.php';
        if ($('#freePackage').hide()) {
            redirect;
        }

    });
});


