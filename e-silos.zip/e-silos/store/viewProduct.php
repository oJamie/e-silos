<?php
//session_start();
require_once 'session.php';

require '../config/db_config.php';
//echo $_SESSION['category'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>E-silos Online Shop</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Bootstrap styles -->
        <link href="assets/css/bootstrap.css" rel="stylesheet"/>
        <!-- Customize styles -->
        <link href="style.css" rel="stylesheet"/>
        <!-- font awesome styles -->
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <!-- Bootstrap-Core-CSS and W3-css -->
        <link rel="stylesheet" href="../css/w3.css" type="text/css"/>                    
        <link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
        <!--<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />-->
        <!-- Style-CSS -->
        <link rel="stylesheet" href="../css/font-awesome.css" type="text/css" media="all">
        <!-- Font-Awesome-Icons-CSS -->
        <!--        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
                 For-Navigation-CSS 
                <link href="css/lsb.css" rel="stylesheet" type="text/css" media="all">-->

        <!-- Favicons -->
        <link rel="shortcut icon" href="../images/images.png">
    </head>
    <body>
        <div class="agileits_top_menu  w3-small">

            <div class="w3l_header_left ">
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Fiapre Sunyani, Ghana</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i> +(233) 554 228 890</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:enriqueoneil09@gmail.com">e-silos@gmail.com</a></li>
                </ul>
            </div>
            <div class="w3l_header_right">
                <div class="w3ls-social-icons text-left">
                    <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                    <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    <!--<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
                    <a class="linkedin" href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="agileits_w3layouts_banner_nav">
            <nav class="navbar navbar-default">
            </nav>

            <div class="clearfix"> </div>
        </div>
       
       
        <div class="container">
            <div id="gototop"> </div>
            <header id="header">
                <div class="row">
                    <div class="span6">
                        <h1 class="w3-text-green">
                            E-silos Online Store
                        </h1>
                    </div>                    

                </div>
            </header>

            <?php // echo $_SESSION['username']; ?>
            <!--
            Navigation Bar Section 
            -->
            <div class="navbar">
                <div class="navbar-inner">
                    <div class="container">
                        <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>
                        <div class="nav-collapse">
                            <ul class="nav">
                                <li class="active storeHome" id=""><a href="http://localhost/e-silos/store/index.php">Home	</a></li>                               
                                <!--<button type="button" id="storeHome" class="btn btn-default btn-large w3-round"> Home </button>-->
                            </ul>                            
                            <?php // echo  $_SESSION['category']; ?>
                            <ul class="nav w3-right ">
                                <!--<li class="active w3-red"><a href="">DashBoard</a></li>-->                               
                            </ul>                            
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <!-- 
            Body Section 
            -->
            <?php 
                $name = trim($_GET['id']);
//                echo $name;
                $sel = "SELECT * FROM registration WHERE username = $name ";
                            $result = mysqli_query($connection, $sel);
                            
//                            echo  trim($name); 
                            
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)):
            
            ?>
            <div class="row">                 
                <div class="col-lg-12 w3-grey ">
                    <div class="col-lg-2 w3-card-2 jumbotron w3-light-gray">
                        <img src="../profilePictures/<?php echo $row['image']; ?>" width="300" height="100" />
                        <hr>                        
                        <ul class="list-group" style="text-decoration: none; list-style-type: none">
                            <li class="list-group-item"><span class="icon icon-user w3-xlarge w3-text-green"></span> <span><?php echo $row['first_name'] . " " .$row['last_name']; ?></span></li>
                            <!--<li class="list-group-item"><span class="icon icon-map-marker w3-xlarge w3-text-red"></span> <span><?php // echo $row['city']; ?></span></li>-->
                            <li class="list-group-item"><span class="icon icon-phone w3-xlarge w3-text-purple"></span> <span><?php echo $row['phone'];?></span></li><br>
                        </ul>
                    </div>                   
                    <div class="col-lg-5 col-lg-offset-1">
                           <div class="well well-small">
                        <hr class="soften"/>
                        <h3 class="w3-padding-left"><?php echo  $row['first_name'] . " " .$row['last_name']; endwhile;} ?>'s ADs</h3>
                        <div class="row-fluid">
                            <ul class="thumbnails">
                                <?php
                                    $id = trim($_GET['id']);
                                    
                                    $sele = "SELECT * FROM market WHERE username = $id  ";
                                    $results = mysqli_query($connection, $sele);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_assoc($results)):
//                                               
                                ?>                                
                                <li class="span4" >
                                    <div class="thumbnail" style="height: 500px">
                                        <!--<a class="zoomTool" href="#" title="add to cart"><span class="icon-search"></span> QUICK VIEW</a>-->
                                        <a  href="#"><img src="../profilePictures/<?php echo $row['file'] ?>" alt="" height="400" width="300"></a>
                                        <div class="caption">
                                            <h3><?php echo $row['prod_name']?></h3>
                                            <hr>
                                            <h5><?php echo $row['acc_name'] ?></h5>
                                            <small><?php echo $row['description'] ?> </small>                                            
                                            <h4>
                                                <span class="pull-center text-small">₵<?php echo $row['amount'];  ?></span>
                                            </h4>
                                        </div>
                                    </div>
                                </li>
                                <?php
                                endwhile;
                                        }
                                ?>

                            </ul>		
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <!-- 
            Clients 
           
        <a href="#" class="gotop"><i class="icon-double-angle-up"></i></a>
            <!-- Placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/jquery.easing-1.3.min.js"></script>
            <script src="assets/js/jquery.scrollTo-1.4.3.1-min.js"></script>
            <script src="assets/js/shop.js"></script>
            
            <script type="text/javascript" lang="javascript">
//                $('.storeHome').click(function (){
//                    
//                    var session = $('.storeHome').attr('id');
////                    document.write("You will be redirected to main page in 10 sec.");
////                    setTimeout('Redirect()', 10000);
//                        console.log(session);
//                    if (session == 'farmer'){
//                        window.location = "http://localhost/e-silos/farmer/index.php";
//                    }
//                    else if (session == 'trader'){
//                        window.location = "http://localhost/e-silos/trader/index.php";
//                    }
//                });
            </script>
    </body>
</html>