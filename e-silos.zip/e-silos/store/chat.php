<?php
//session_start();
require_once 'session.php';

require '../config/db_config.php';
//echo $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>e-silos Online Shop</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Bootstrap styles -->
        <link href="assets/css/bootstrap.css" rel="stylesheet"/>
        <!-- Customize styles -->
        <link rel="icon" type="icon" href="../images/images.png"/>
        <!-- Bootstrap Core CSS -->
        <link href="../Admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../Admin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../Admin/dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="../Admin/vendor/morrisjs/morris.css" rel="stylesheet">

        <link href="style.css" rel="stylesheet"/>
        <!-- font awesome styles -->
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="../css/w3.css" rel="stylesheet">        
        <link rel="shortcut icon" href="../images/images.png">

    </head>
    <body>
        <!-- 
                Upper Header Section 
       
        <!--
        Lower Header Section 
        -->
        <div class="container">
            <div id="gototop"> </div>
            <header id="header">
                <div class="row">
                    <div class="span6">
                        <h1 class="w3-text-green">
                            e-silos Online Store
                        </h1>
                    </div>                    

                </div>
            </header>

            <!--
            Navigation Bar Section 
            -->
            <div class="navbar">
                <div class="navbar-inner">
                    <div class="container">
                        <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>
                        <div class="nav-collapse">
                            <ul class="nav">
                                <!--<li class="active"><a href="index.php">Home	</a></li>-->                               
                                <!--<li class="active w3-right" ><a href="index.php">Quit Chat	</a></li>-->                               
                            </ul>                            
                            <ul class="nav w3-right ">
                                <li class="active w3-red"><a href="index.php" >Leave Chat</a></li>                               
                            </ul>                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- 
            Body Section 
            -->                          
            <div class="row">                 
                <div class="col-lg-12">                    
                    <div class="panel-body">
                        <div class="jumbotron w3-white w3-card-4" style="height: 450px; width: 100%; overflow: scroll" id="messageContainer"></div>                        
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group w3-card">
                                <textarea autofocus="" class="form-control" name="message" id="message" rows="3" placeholder="Enter Message Here...."></textarea>                                    
                            </div>
                            <button type="button" class="w3-right btn btn-primary" id="send_message">
                                Send 
                                <span class="icon-envelope"></span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/jquery.easing-1.3.min.js"></script>
            <script src="assets/js/jquery.scrollTo-1.4.3.1-min.js"></script>
            <script src="assets/js/shop.js"></script>
            <script src="../execution/chat.js"></script>


    </body>
</html>