<?php
//session_start();
require_once 'session.php';

require '../config/db_config.php';
//echo $_SESSION['category'];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>E-silos Online Shop</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="format-detection" content="telephone=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <!-- Bootstrap styles -->
        <link href="assets/css/bootstrap.css" rel="stylesheet"/>
        <!-- Customize styles -->
        <link href="style.css" rel="stylesheet"/>
        <!-- font awesome styles -->
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <!-- Bootstrap-Core-CSS and W3-css -->
        <link rel="stylesheet" href="../css/w3.css" type="text/css"/>                    
        <link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
        <!--<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />-->
        <!-- Style-CSS -->
        <link rel="stylesheet" href="../css/font-awesome.css" type="text/css" media="all">
        <!-- Font-Awesome-Icons-CSS -->
        <!--        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
                 For-Navigation-CSS 
                <link href="css/lsb.css" rel="stylesheet" type="text/css" media="all">-->

        <!-- Favicons -->
        <link rel="shortcut icon" href="../images/images.png">
    </head>
    <body>
        <div class="agileits_top_menu  w3-small">

            <div class="w3l_header_left ">
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Fiapre Sunyani, Ghana</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i> +(233) 554 228 890</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:enriqueoneil09@gmail.com">e-silos@gmail.com</a></li>
                </ul>
            </div>
            <div class="w3l_header_right">
                <div class="w3ls-social-icons text-left">
                    <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                    <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    <!--<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
                    <a class="linkedin" href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="agileits_w3layouts_banner_nav">
            <nav class="navbar navbar-default">
            </nav>

            <div class="clearfix"> </div>
        </div>

        <div class="container">
            <div id="gototop"> </div>
            <header id="header">
                <div class="row">
                    <div class="span6">
                        <h1 class="w3-text-green">
                            E-silos Online Store
                        </h1>
                    </div>                    

                </div>
            </header>

            <!--
            Navigation Bar Section 
            -->
            <div class="navbar">
                <div class="navbar-inner">
                    <div class="container">
                        <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </a>
                        <div class="nav-collapse">
                            <ul class="nav">
                                <li class="active storeHome" id=""><a href="http://localhost/e-silos/<?php echo$_SESSION['category']; ?>/index.php">DashBoard	</a></li>                               
                                <!--<button type="button" id="storeHome" class="btn btn-default btn-large w3-round"> Home </button>-->
                            </ul>                            
                            <?php // echo  $_SESSION['category']; ?>
                            <ul class="nav w3-right ">
                                <!--<li class="active w3-red"><a href="">DashBoard</a></li>-->                               
                            </ul>                            
                        </div>
                    </div>
                </div>
            </div>
            <!-- 
            Body Section 
            -->
            <div class="row" >                 
                <div class="span12">
                    <!--<h3>hy</h3>-->
                    <div class="well well-small">
                        <hr class="soften"/>
                        <div class="row-fluid">
                            <ul class="thumbnails">
                                <?php
                                $sel = "SELECT * FROM market  ";
                                $result = mysqli_query($connection, $sel);

                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_array($result)):
//                                               
                                        ?>                                
                                        <li class="span4" >
                                            <div class="thumbnail" style="height: 550px">
                                                <!--<a class="zoomTool" href="#" title="add to cart"><span class="icon-search"></span> QUICK VIEW</a>-->
                                                <a  href="viewProduct.php?id='<?php echo trim($row['username']) ?>'"><img src="../profilePictures/<?php echo $row['file'] ?>" alt="" height="400" width="300"></a>
                                                <div class="caption">
                                                    <h3><?php echo $row['prod_name'] ?></h3>
                                                    <!--<hr>-->
                                                    <h5><?php echo $row['acc_name'] ?></h5>
                                                    <h5 class="icon-map-marker" style="text-decoration: transparent"> <?php echo $row['city'] ?></h5>
                                                    <hr>
                                                    <h4>
                                                        <a class="shopBtn reqPhone" id="<?php echo $row['acc_number']; ?>"  title="" ><span class="icon-phone " ></span></a><br>                                                
                                                        <input class="w3-input w3-small w3-margin-top displayPhone" value="Contact on <?php echo $row['acc_number'] ?>" />                                                
                                                    </h4>
                                                    <small><?php echo $row['description'] ?> </small>                                            
                                                    <h4>
                                                        <span class="pull-center text-small">₵<?php echo $row['amount']; ?></span>
                                                    </h4>
                                                    <h4>
                                                        <a class="defaultBtn w3-green sms"  href="sms: '<?php echo $acc_number; ?>' " ><span class="icon-envelope " ></span></a>
                                                        <a class="shopBtn call" href="tel: '<?php echo $row['acc_number'] ?>.' " title="" ><span class="icon-phone " ></span></a><br>
                                                        <!--<span class="pull-center"><?php echo $row['amount']; ?></span>-->
                                                    </h4>
                                                    <a  href="viewProduct.php?id='<?php echo trim($row['username']) ?>'"><span class="w3-padding-left w3-text-green"> AD <em>posted  by</em> <?php echo $row['username']; ?></span></a>                                        
                                                </div>
                                            </div>
                                        </li>
                                        <?php
                                    endwhile;
                                }
                                ?>

                            </ul>		
                        </div>
                    </div>

                </div>
            </div>
            <!-- 
            Clients 
           
        <a href="#" class="gotop"><i class="icon-double-angle-up"></i></a>
            <!-- Placed at the end of the document so the pages load faster -->
            <script src="assets/js/jquery.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/jquery.easing-1.3.min.js"></script>
            <script src="assets/js/jquery.scrollTo-1.4.3.1-min.js"></script>
            <script src="assets/js/shop.js"></script>

            <script type="text/javascript" lang="javascript">
                $(document).ready(function () {
//                    var width = window.screen.availWidth;
//                    var height = window.screen.availHeight; 
                    var orientation = {
                        width: window.screen.availWidth,
                        height: window.screen.availHeight
                    };

                    var Phones = {
                        iphone5: "640×1136",
                        iphone6: "750×1334",
                        iphone6Plus: "1242×2208",
                        iphone7: "750x1334",
                        iphone8: "750x1334",
                        iphoneX: "1125x2436",
                        samsungS6: "1440x2560",
                        samsungS7: "2960x1440"
                    };
                    console.log(Phones);
                    console.log(orientation);

                    if (orientation === Phones) {
                        $('.sms').show();
                        $('.call').show();
                    } else {
                        $('.sms').hide();
                        $('.call').hide();
                    }

                    var id = $(this).attr('id');
                    console.log(id);

                    $('.displayPhone').hide();

                    $('.reqPhone').click(function () {
                        $('.displayPhone').toggle();
                    });

                });
            </script>
    </body>
</html>