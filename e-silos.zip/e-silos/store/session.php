<?php
session_start();// Starting Session

if(!isset($_SESSION['username']))
{
	header("location: http://localhost/e-silos/index.php");
}
else{
    $_SESSION['username'];
    $_SESSION['category'];
}
?>