<?php
//session_start();
require_once 'session.php';

require '../config/db_config.php';
//$_SESSION['username'] = $username;
?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>e-silos | trader Dashboard</title>

        <link rel="icon" type="icon" href="../images/images.png"/>
        <!-- Bootstrap Core CSS -->
        <link href="../Admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../Admin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../Admin/dist/css/sb-admin-2.css" rel="stylesheet">
        <link href="../css/styles4.css" rel="stylesheet" type="text/css">
        <link href="../css/w3.css" rel="stylesheet" type="text/css">
        <link href="../css/jquery-confirm.css" rel="stylesheet" type="text/css">


        <!-- Morris Charts CSS -->
        <link href="../Admin/vendor/morrisjs/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../Admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../css/w3.css" rel="stylesheet" type="text/css">
        <link href="../css/datatables.min.css" rel="stylesheet" type="text/css">


    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">e-silos</a>
                </div>
                <!-- /.navbar-header -->

                <ul class="nav navbar-top-links navbar-right">
                    <!-- /.dropdown -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li>
                                <a href="profile.php"><i class="fa fa-user fa-fw"></i>  Profile</a>
                            </li>
                    </li>
                    <li class="divider"></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
                <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">                        
                            <li>
                                <a href="index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                            </li>                                                   
                            <li>
                                <a href="storage.php"><i class="fa fa-save fa-fw"></i> Storage</a>
                            </li>
                            <li>
                                <a href="notification.php"><i class="fa fa-microphone fa-fw"></i> Notification</a>
                            </li>
                            <li>
                                <a href="mailbox.php"><i class="fa fa-envelope fa-fw"></i> MailBox</a>
                            </li>
                            <li>
                                <a href="weather.php"><i class="fa fa-cloud fa-fw"></i> Weather</a>
                            </li>
                            <li>
                                <a href="market.php"><i class="fa fa-shopping-bag"></i> My Market<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">                               
                                    <li>
                                        <a href="viewAD.php" class="fa fa-cart-arrow-down"> My ADs</a>
                                    </li>
                                    <li>
                                        <a href="postAd.php" class="fa fa-cart-plus"> Post ADs</a>
                                    </li>
                                    <li>
                                        <a href="#" class="fa fa-shopping-cart" target="_blank">Store</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-cog fa-fw"></i> Settings<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">                               
                                    <li>
                                        <a href="profile.php" class="fa fa-user"> Profile</a>
                                    </li>
                                    <li>
                                        <a href="logout.php" class="fa fa-sign-out">Logout</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Storage</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-cloud fa-5x"></i>
                                    </div>
                                    <div class="huge text-center"style="" >
                                        <span></span>
                                    </div>
                                    <div class="col-xs-9 text-right">                                       
                                        <div>Weather </div>
                                    </div>
                                </div>
                            </div>
                            <a href="weather.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div> 
                                    <div class="huge text-center"></div>
                                    <div class="col-xs-9 text-right">                                        
                                        <div>Storage </div>
                                    </div>
                                </div>
                            </div>
                            <a href="storage.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View </span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-envelope fa-5x"></i>
                                    </div>
                                    <div class="huge">                                      
                                    </div>
                                    <div class="col-xs-9 text-right">                                       
                                        <div>MailBox</div>
                                    </div>
                                </div>
                            </div>
                            <a href="mailbox.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View </span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-bell fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"></div>
                                        <div>Online Store</div>
                                    </div>
                                </div>
                            </div>
                            <a href="http://localhost/e-silos/store/index.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <button type="button" id="buyPackage" class="w3-right btn btn-primary" onclick="window.location = 'storage.php'">
                        <span class="fa fa-arrow-circle-left"></span>
                        Back
                    </button><br>
                    <hr>                   
                    <div class="col-lg-12">

                        <section class="pricing-table">
                            <div class="container">                              
                                <div class="block-heading">
                                    <h2>Buy Storage</h2>
                                    <h5 class="w3-center">Why Need a Storage</h5>
                                    <ul class="list-unstyled text-small text-center">
                                        <li><a class="text-muted" href="#">Easy delivery of products</a></li>
                                        <li><a class="text-muted" href="#">Reduce loss of resources</a></li>
                                        <li><a class="text-muted" href="#">Rapid Delivery</a></li>
                                        <li><a class="text-muted" href="#">Ensure reduction of perished products</a></li>                                       
                                    </ul>

                                </div>

                                <div class="row justify-content-md-center">

                                   <div class="col-md-5 col-lg-12">
                                        <?php
                                        $sel = "SELECT * FROM storage_plan WHERE packageType = 'PRO' ";
                                        $result = mysqli_query($connection, $sel);

                                        if (mysqli_num_rows($result) > 0) {
                                            while ($row = mysqli_fetch_array($result)):
//                                               
                                                ?>
                                        <div class="item">
                                            <div class="ribbon">Best Value</div>
                                            <div class="heading">
                                                <h3 id="packageType"><?php echo $row['packageType']; ?></h3>
                                            </div>
                                            <!--<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
                                            <div class="features">
                                                        <h4 id="detail"><span class="value"><?php echo $row['detail']; ?></span></h4>
                                                        <h4 id="support"><span class="feature">Full Support</span> : <span class="value"> <?php echo $row['support']; ?></span></h4>
                                                        <h4 id="delivery"><span class="feature">Free Delivery</span> : <span class="value"> <?php echo $row['delivery']; ?></span></h4>
                                                        <h4 id="duration"><span class="feature">Duration</span> : <span class="value"><?php echo $row['duration']; ?></span></h4>
                                                        <h4 id="capacity"><span class="feature">Storage</span> : <span class="value"><?php echo $row['capacity']; ?></span></h4>
                                                        <h4 id="refund"><span class="feature">Refundability</span> : <span class="value"><?php echo $row['refund']; ?></span></h4>
                                                    </div>
                                            <div class="price">
                                                <h4 id="price">₵<?php echo $row['price'];
                                    endwhile;
                                } ?></h4>
                                            </div>
                                            <button class="btn btn-block btn-success" type="button" id="buyNow">BUY NOW</button>
                                        </div>
                                    </div>

                                </div>
                        </section>

                    </div>   

                </div>

            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../Admin/vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../Admin/vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../Admin/vendor/metisMenu/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../Admin/dist/js/sb-admin-2.js"></script>
        <script src="../js/datatables.min.js"></script>
        <script src="../js/jquery-confirm.js"></script>
        <script>
                        $('#storageTable').DataTable();
                        
//                disabling my free trail after click.
                $('#buyNow').click(function(){
                    location = 'payPackage.php';                    
                });
        </script>
    </body>

</html>

