<?php
//session_start();
require_once 'session.php';

require '../config/db_config.php';
$display = '';

if (isset($_POST['updateProfile'])) {
    $username = $_POST['username'];
    $firstName = $_POST['first_name'];
    $lastName = $_POST['last_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $acc_name = $_POST['acc_name'];
    $acc_number = $_POST['acc_number'];

// The directory that will recieve the uploaded file
    $name = $_FILES['image']['name'];
    $target_dir = "../profilePictures/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);

// Select file type
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

// Valid file extensions
    $extensions_arr = array("jpg", "jpeg", "png", "gif");


// Check extension
    if (in_array($imageFileType, $extensions_arr)) {
// Insert record           
        $sql = " UPDATE registration SET username = '$username', first_name = '$firstName', last_name = '$lastName', phone = '$phone', email = '$email', acc_name = '$acc_name', acc_number = '$acc_number', image = '$name' WHERE username = '{$_SESSION['username']}' ";
        $result = mysqli_query($connection, $sql);
// Upload file
        move_uploaded_file($_FILES['image']['tmp_name'], $target_dir . $target_file);


        if ($result == TRUE) {
            echo "<script>alert('Profile Updated');</script>";
        } else {
            echo "<script>alert('Profile Not Updated');</script>" . $connection->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>e-silos | trader Dashboard</title>

        <link rel="icon" type="icon" href="../images/images.png"/>
        <!-- Bootstrap Core CSS -->
        <link href="../Admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../Admin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../Admin/dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="../Admin/vendor/morrisjs/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../Admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../css/w3.css" rel="stylesheet" type="text/css">
        <link href="../css/style.css" rel="stylesheet" type="text/css">


    </head>

    <body>
        <div class="agileits_top_menu  w3-small">

            <div class="w3l_header_left ">
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Fiapre Sunyani, Ghana</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i> +(233) 554 228 890</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:enriqueoneil09@gmail.com">e-silos@gmail.com</a></li>
                </ul>
            </div>
            <div class="w3l_header_right">
                <div class="w3ls-social-icons text-left">
                    <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                    <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    <!--<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
                    <a class="linkedin" href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>       
        <div id="wrapper">          
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">                        
                        <li>
                            <a href="index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>                                                   
                        <!--                            <li>
                                                        <a href="storage.php"><i class="fa fa-save fa-fw"></i> Storage</a>
                                                    </li>-->
                        <li>
                            <a href="notification.php"><i class="fa fa-microphone fa-fw"></i> Notification</a>
                        </li>
                        <li>
                            <a href="mailbox.php"><i class="fa fa-envelope fa-fw"></i> MailBox</a>
                        </li>                            
                        <li>
                            <a href="#"><i class="fa fa-cog fa-fw"></i> Settings<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                               
                                <li>
                                    <a href="profile.php" class="fa fa-user"> Profile</a>
                                </li>
                                <li>
                                    <a href="../logout.php" class="fa fa-sign-out">Logout</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Profile</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bell fa-5x"></i>
                                </div>
                                <div class="huge text-center"style="" >
                                    <span></span>
                                </div>
                                <div class="col-xs-9 text-right">                                       
                                    <div>Notification </div>
                                </div>
                            </div>
                        </div>
                        <a href="notification.php">
                            <div class="panel-footer">
                                <span class="pull-left">View</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user fa-5x"></i>
                                </div> 
                                <div class="huge text-center"></div>
                                <div class="col-xs-9 text-right">                                        
                                    <div>Profile </div>
                                </div>
                            </div>
                        </div>
                        <a href="profile.php">
                            <div class="panel-footer">
                                <span class="pull-left">View </span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-envelope fa-5x"></i>
                                </div>
                                <div class="huge">                                      
                                </div>
                                <div class="col-xs-9 text-right">                                       
                                    <div>MailBox</div>
                                </div>
                            </div>
                        </div>
                        <a href="mailbox.php">
                            <div class="panel-footer">
                                <span class="pull-left">View </span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bell fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"></div>
                                    <div>Online Store</div>
                                </div>
                            </div>
                        </div>
                        <a href="http://localhost/e-silos/store/index.php">
                            <div class="panel-footer">
                                <span class="pull-left">View</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <button type="button" class="btn-circle w3-white fa fa-edit w3-right" data-toggle="modal" data-target="#editProfile"></button>                                                        
                            <h3>User Registration </h3>
                        </div>
                        <div class="panel-body">
                            <form method="post" enctype="multipart/form-data">
                                <?php
                                $sql = "SELECT * FROM registration WHERE username = '{$_SESSION['username']}' ";
                                $result = mysqli_query($connection, $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    // output data of each row
                                    $row = mysqli_fetch_assoc($result);
                                    ?>
                                    <div class="col-md-6">
                                        <div class="w3-card-4 w3-padding">
                                            <img src="../profilePictures/<?php echo $row['image']; ?>" class="thumbnail" height="300" />
                                            <!--                                                    <button type="button" class="btn btn-circle btn-danger" id="deleteImage">
                                                                                                    <span class="fa fa-trash"></span>
                                                                                                </button>-->
                                            <br><hr>
                                        </div>
                                    </div>
                                    <div class="col-md-6">                                                                          
                                        <div class="list-group" id="list-tab" role="tablist">
                                            <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">
                                                Username <button class="btn btn-default btn-block w3-text-blue"><?php echo $row['username']; ?></button>
                                            </a>
                                            <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">
                                                Name<button class="btn btn-primary btn-block w3-text-white"><?php echo $row['first_name'] . " " . $row['last_name']; ?></button>
                                            </a>
                                            <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">
                                                Phone<button class="btn btn-primary btn-block w3-text-white"><?php echo $row['phone']; ?></button>
                                            </a>
                                            <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="list" href="#list-settings" role="tab" aria-controls="settings">
                                                Email<button class="btn btn-primary btn-block w3-text-white"><?php echo $row['email']; ?></button>
                                                <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">
                                                    Account Name<button class="btn btn-primary btn-block w3-text-white"><?php echo $row['acc_name']; ?></button>
                                                </a>
                                                <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="list" href="#list-messages" role="tab" aria-controls="messages">
                                                    Account Number<button class="btn btn-primary btn-block w3-text-white"><?php echo $row['acc_number']; ?></button>
                                                </a>                                                 
                                        </div>

                                    </div>
                                    <br>
                                    <hr>
                                    <!--                                    <div class="col-md-6">                                                                        
                                                                            <div class="list-group" id="list-tab" role="tablist">
                                                                                <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Password
                                                                                    <button class=" fa fa-edit w3-right btn btn-circle w3-white"></button>
                                                                                </a>                                                
                                                                            </div>                                     
                                                                        </div>-->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /#page-wrapper -->
                <!-- Modal -->
                <div class="modal fade" id="editProfile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title w3-text-black w3-center" id="exampleModalLabel">Edit Profile</h5>
                            </div>
                            <div class="modal-body w3-text-black">
                                <form method="POST" enctype="multipart/form-data" >
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">First Name</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $row['first_name'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Last Name</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $row['last_name'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Phone</label>
                                        <input type="phone" class="form-control" id="phone" name="phone" value="<?php echo $row['phone'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Email</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Account Name</label>
                                        <input type="text" class="form-control" id="acc_name" name="acc_name" value="<?php echo $row['acc_name'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Account Number</label>
                                        <input type="text" class="form-control" id="acc_name" name="acc_number" value="<?php echo $row['acc_number'];
                                            } ?>">
                                </div>
                                <div class="form-group">
                                    <label for="image">Image</label>
                                    <input type="file"  class="dropify" name="image" id="image" data-min-width="400" >                                                        
                                </div>                   
                                <hr>
                                <button type="submit" id="updateProfile" name="updateProfile" class="btn btn-primary w3-right">Update Profile</button>
                                <br>
                                <br>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                            <!--<button type="button" class="btn btn-primary">Save changes</button>-->
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../Admin/vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../Admin/vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../Admin/vendor/metisMenu/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../Admin/dist/js/sb-admin-2.js"></script>
        <script>
//            $(".alert").alert('close');
        </script>
</body>

</html>

