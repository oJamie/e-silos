<?php
session_start();


if(!empty($_POST['phone'])){
        $phone = $_POST['phone'];
	$msg = nl2br($_POST['msg']);
	$message = rawurlencode("Payment Completed, Here is your confirmation code : + $msg");
 
		$retel = $phone+0;
		$url = "https://api.hubtel.com/v1/messages/send?"
		  . "From=ESilos"
		  . "&To=%2B233".$retel
		  . "&Content=$message"
		  . "&ClientId=qfamiola"
		  . "&ClientSecret=mmvlvjgs"
		  . "&RegisteredDelivery=true";
	   // Fire the request and wait for the response
	   $response = file_get_contents($url) ;
	   //var_dump($response);
	echo 'Message sent successully!';	
}
else {
	echo 'All fields are required';
}
?>