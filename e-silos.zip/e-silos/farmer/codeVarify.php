<?php
session_start();
if(isset($_POST['code']) && !empty($_POST['code'])){
	$scode = $_POST['code'];
	if($scode == $_SESSION['code']){
		header("Location: congrats.php");
	}
}
?>