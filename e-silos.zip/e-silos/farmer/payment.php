<?php

//sk_test_0S1bGUvhn0KjRt1tknCXtmHi

require_once('stripe-php-6.4.2/init.php');

\Stripe\Stripe::setApiKey('sk_test_0S1bGUvhn0KjRt1tknCXtmHi');

$error = array();
//$amount = base64_decode($_GET['fee']);

if (isset($_POST['name']) && isset($_POST['email'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $token = trim($_POST['stripeToken']);
    $message = "This is your payment token: <strong style='font-size: 20px;'>" . $token . "</strong>. Keep it safe for future purpose.";
    $subject = "PAYMENT SUCCESSFUL - UASGH";

    //create customer in stripe
    $customer = \Stripe\Customer::create(array(
                'email' => $email,
                'source' => $token
    ));

    //charge customer
    $charge = \Stripe\Charge::create(array(
                'amount' => $amount,
                'currency' => 'usd',
                'description' => 'Form Payment',
                'customer' => $customer->id
    ));

    // Transaction Data
    $transactionData = [
        'id' => $charge->id,
        'customer_id' => $charge->customer,
        'exp_year' => $charge->exp_year,
        'amount' => $charge->amount,
        'currency' => $charge->currency,
        'status' => $charge->status
    ];

    // Customer Data
    $customerData = [
        'id' => $charge->customer,
        'email' => $email
    ];


    if ($charge->status == "succeeded") {
        try {

            $statement = $db->prepare("INSERT INTO applicant_payment
                                           (cust_id,student_id,email,transaction_status,
                                           transaction_token,transaction_date)
                                           VALUES
                                           (:cust_id,:student_id,:email,:transaction_status,
                                           :transaction_token,now())
                                            ");



            $statement->execute(array(
                "cust_id" => $customerData['id'],
                "student_id" => $_SESSION['user_session'],
                "email" => $customerData['email'],
                "transaction_status" => $transactionData['status'],
                "transaction_token" => $token
            ));
            if ($statement) {
                
                if(($user->send_mail($email, $message, $subject)) && ($transactionData['status'] == 'succeeded')){
                    $statement1 = $db->prepare("UPDATE student_institutions
                                                SET admission_status = :status,admission_progress = :progress
                                                WHERE student_id = :id");
                    $statement1->execute(array(
                        "status" => 'in progress',
                        "progress"=> '40%',
                        "id" => $_SESSION['user_session']
                    ));
                    if($statement1){
                        $result = $user->showSwalMessage("Success", "Tansaction Successful", "success");
                        header('Refresh: 5; student_dashboard?payment_status='.$transactionData['status']);
                    }
                                                
                }else{
                    $error[] = "Unable to send mail or Error in Transaction";
                }
                
            } else {
                $error[] = "Error in Transaction";
            }
        } catch (PDOException $ex) {
            $error[] = $ex->getMessage();
        }
    }
}

