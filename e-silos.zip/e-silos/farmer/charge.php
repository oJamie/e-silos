<?php
//sk_test_0S1bGUvhn0KjRt1tknCXtmHi
require 'session.php';
require '../config/db_config.php';

    require_once('stripe-php-6.4.2/init.php');
    
    \Stripe\Stripe::setApiKey('sk_test_0S1bGUvhn0KjRt1tknCXtmHi');
    
    if(isset($_POST['stripeToken'])){               
        $token = trim($_POST['stripeToken']);
//        echo $token;
        
        //create customer in stripe
        $customer = \Stripe\Customer::create(array(           
            'source' => $token
        ));
        
        //charge customer
        $charge = \Stripe\Charge::create(array(
            'amount' => 500, 
            'currency' => 'usd',
            'description' => 'Sotage Payment',
            'customer' => $customer->id
        ));
        
        // Transaction Data
        $transactionData = [
            'id' => $charge->id,
            'username' => $charge->customer,
            'currency' => $charge->currency,
            'amount' => $charge->amount,            
            'status' => $charge->status
        ];
        
        if ($charge->status == "succeeded") {
            try {

                $statement = "SELECT * FROM storage_plan";
                $statementResult = mysqli_query($connection, $statement);
               
                if (mysqli_num_rows($statementResult) > 0) {
                   $row = mysqli_fetch_assoc($statementResult);
                        $packageType = $row['packageType'];
                        $code = $row['code'];
                        $detail = $row['detail'];
                        $price = $row['price'];
                        $duration = $row['duration'];
                        $capacity = $row['capacity'];
                        $support = $row['support'];
                        $delivery = $row['delivery'];
                        $refund = $row['refund'];
                        
                        
                $statement1 = "INSERT INTO `user_storage` (`packageType`, `code`, `detial`, `price`, `duration`, `capacity`, `support`, `delivery`, `refund`, `username`, `status`) "
                            . "VALUES ('$packageType','$code','$detail','$price','$duration','$capacity','$support','$delivery','$refund','{$_SESSION['username']}','PAID')";
             
//                    $statement1 = "INSERT INTO user_storage (packageType, code, detail, price, duration, capacity, support, delivery, refund, username, status)
//                                    VALUES ('{$packageType}','{$code}','{$detail}','{$price}','{$duration}','{$capacity}','{$support}','{$delivery}','{$refund}','{$_SESSION['username']}','Paid')"; 
                                    $result = mysqli_query($connection, $statement1);
                                   
//                                    echo $result;
                       if($statement1){
//                           print_r($statement1);
                            echo "<script> alert('Tansaction Successful'); </script>";
                            header('Refresh: 5; http://localhost/e-silos/farmer/storage.php');
                        }
                        else if (!$statement){
                            echo "<script> alert('Failed making Transaction'); </script>".$connection->error;
                        }
                        else{
                                    echo "<script> alert('Error in Transaction'); </script>";
                             }
                  
                } 
                 else {
                    $error[] = "<script> alert('Error in Transaction'); </script>";
                }
            }
    catch (PDOException $ex) {
                $error[] = $ex->getMessage();
            }
//        print_r($charge);
        }
   

    }