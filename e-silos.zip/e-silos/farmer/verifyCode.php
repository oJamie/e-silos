
<?php
        set_error_handler(function(){});
        session_start();
        $username = $_SESSION['username'];

        $rd = mt_rand(1000,9999);
        $_SESSION['code'] = $rd;

        $phone = $_SESSION['phone'];
                $msg = $rd;
                $message = rawurlencode('Payment Completed, Here is your confirmation code : '."$msg");

                        $retel = $phone+0;
                        $url = "https://api.hubtel.com/v1/messages/send?"
                          . "From=E-silos"
                          . "&To=%2B233".$retel
                          . "&Content=$message"
                          . "&ClientId=qfamiola"
                          . "&ClientSecret=mmvlvjgs"
                          . "&RegisteredDelivery=true";
                   // Fire the request and wait for the response
                   $response = file_get_contents($url) ;
        ?>
<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>E-silos | Farmer Dashboard</title>

        <link rel="icon" type="icon" href="../images/images.png"/>
        <!-- Bootstrap Core CSS -->
        <link href="../Admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../Admin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../Admin/dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="../Admin/vendor/morrisjs/morris.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../Admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../css/w3.css" rel="stylesheet" type="text/css">
        <link href="../css/datatables.min.css" rel="stylesheet" type="text/css">
        <link href="../css/jquery-confirm.css" rel="stylesheet" type="text/css">


    </head>

    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">e-silos</a>
                </div>
                <!-- /.navbar-header -->

                <ul class="nav navbar-top-links navbar-right">
                    <!-- /.dropdown -->
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li>
                                <a href="profile.php"><i class="fa fa-user fa-fw"></i>  Profile</a>
                            </li>
                    </li>
                    <li class="divider"></li>
                    <li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
                <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">                        
                            <li>
                                <a href="index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                            </li>                                                   
                            <li>
                                <a href="storage.php"><i class="fa fa-save fa-fw"></i> Storage</a>
                            </li>
                            <li>
                                <a href="notification.php"><i class="fa fa-microphone fa-fw"></i> Notification</a>
                            </li>
                            <li>
                                <a href="mailbox.php"><i class="fa fa-envelope fa-fw"></i> MailBox</a>
                            </li>
                            <li>
                                <a href="weather.php"><i class="fa fa-cloud fa-fw"></i> Weather</a>
                            </li>
                            <li>
                                <a href="market.php"><i class="fa fa-shopping-bag"></i> My Market<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">                               
                                    <li>
                                        <a href="viewAD.php" class="fa fa-cart-arrow-down"> My ADs</a>
                                    </li>
                                    <li>
                                        <a href="postAd.php" class="fa fa-cart-plus"> Post ADs</a>
                                    </li>
                                    <li>
                                        <a href="http://localhost/e-silos/store/" class="fa fa-shopping-cart">Store</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-cog fa-fw"></i> Settings<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">                               
                                    <li>
                                        <a href="profile.php" class="fa fa-user"> Profile</a>
                                    </li>
                                    <li>
                                        <a href="../logout.php" class="fa fa-sign-out">Logout</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Storage</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-cloud fa-5x"></i>
                                    </div>
                                    <div class="huge text-center"style="" >
                                        <span></span>
                                    </div>
                                    <div class="col-xs-9 text-right">                                       
                                        <div>Weather </div>
                                    </div>
                                </div>
                            </div>
                            <a href="weather.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div> 
                                    <div class="huge text-center"></div>
                                    <div class="col-xs-9 text-right">                                        
                                        <div>Storage </div>
                                    </div>
                                </div>
                            </div>
                            <a href="storage.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View </span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-envelope fa-5x"></i>
                                    </div>
                                    <div class="huge">                                      
                                    </div>
                                    <div class="col-xs-9 text-right">                                       
                                        <div>MailBox</div>
                                    </div>
                                </div>
                            </div>
                            <a href="mailbox.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View </span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-bell fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"></div>
                                        <div>Online Store</div>
                                    </div>
                                </div>
                            </div>
                            <a href="http://localhost/e-silos/store/index.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                
                
                <div class="container">
                    <br>
                    
                    <h3> Verify Payment</h3>
                    <hr>
                    <div class="col-lg-12">
                        
                        <form method="POST" action autocomplete="off">
                            <div class="form-group">
                                <input type="text" name="code" id="username" class="form-control" autofocus="" size="4" required="" placeholder="Verification Code" min="1" max="4"  />
                            </div>
                            
                            <div class="form-group ">
                                <input type="submit" class="btn btn-success  w3-right w3-margin-bottom btn-lg" name="signup" value="Verify" />
                            </div>
                        </form>
                    </div>
                </div>
<!--   <div class="container ">
    
    <div class="w3-center">
    </div>
       
    <div class="row" >                       
        <div class="container">                        
            <div class="content w3-card-4 w3-round w3-margin-top w3-white w3-bordered" id="secondContent" style="height: 400px; margin-bottom: 20px">
                <h1 class="w3-xlarge text-center"> E-silos Trader Registration Page</h1>    
                <h2 class="text-center w3-text-green "> Enter Verification Code </h2>
                <hr>
                <h1 class="w3l-logo2 w3-center" style="background: transparent">
                    <a href="index.php"><i class="fa fa-envira" aria-hidden="true"></i>E-Silos</a>
                </h1> 
                <h1 class="text-center w3-padding-top" >  Registration </h1>
               
                <form name="form1" id="form1" role="form" method="post" action="codeeVarify.php" class="w3-padding-top content" autocomplete="off" enctype="multipart/form-data" accept-charset="utf8-encode" style="height: 600px">                              
                    <div class="panel panel-default">
                        <div class="panel-heading"><i class="fa fa-user"></i> Personal Verification </div>
                        <div class="panel-body"> 
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-addon"><span class="fa fa-key"></span></span>
                                    <input type="text" name="code" id="username" class="form-control" autofocus="" size="4" required="" placeholder="Verification Code" min="1" max="4"  />
                                    <label for="fname"> User Name </label>
                                </div>
                            </div>                                                                       
                            <div class="form-group ">
                                <input type="submit" class="btn btn-success w3-hover-blue w3-right w3-margin-bottom w3-border-0" name="signup" value="Verify" />
                            </div>                       
                        </div>
                    </div>    
                </form>
            </div>

        </div>
    </div>
</div>-->