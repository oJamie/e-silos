<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM registration ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                   
                                 <td data-id1="' . $row["id"] . '" >' . $row["id"] . '</td>                                                                      
                                 <td data-id2="' . $row["id"] . '" >' . $row["username"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["first_name"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["last_name"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["category"] . '</td>                                                                      
                                 <td data-id6="' . $row["id"] . '" >' . $row["phone"] . '</td>                                                                      
                                 <td data-id7="' . $row["id"] . '" >' . $row["acc_name"] . '</td>                                                                      
                                 <td data-id8="' . $row["id"] . '" >' . $row["acc_number"] . '</td>                                                                      
                                 <td data-id9="' . $row["id"] . '" >' . $row["email"] . '</td>    
                                 <td>
                                    <button type="button" class="btn btn-warning "> Deactivate User </button>
                                 </td>    
                            </tr>  
                       ';
                    
                }
        echo $output;
        }