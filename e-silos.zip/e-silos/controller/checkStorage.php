<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $id = $_POST['id'];
    $user = $_POST['id2'];
  
    
    
    $sql = "SELECT code FROM storage_plan";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                $row = mysqli_fetch_array($result);
                    $row['code'];
                    
                    
                $select_data = "SELECT * FROM user_storage WHERE username = '$user' ";
                $results = mysqli_query($connection_ref, $select_data);        

                    if (mysqli_num_rows($result) >= 0) {            
                            $rows = mysqli_fetch_array($results);
                                $rows['code'];
                                $rows['duration'];
                    
                              if ($row['code'] == $rows['code']){
                              echo " Already Using this package, Wait for " . $rows['duration'] . " To renew";
                                  return false;
                              }  else {
                                  echo "Continue to purchase";
                              }
                    }

        }