<?php

include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $id  = $_POST['id'];

    $sql = "SELECT * FROM coordinator WHERE id = '$id' ";
        $result = mysqli_query($connection_ref, $sql);        

            //echo 'here';
            $response = array();
        if (mysqli_num_rows($result) >= 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $username = $row['username'];
                $first_name = $row['first_name'];
                $last_name = $row['last_name'];
                $phone = $row['phone'];
                $email = $row['email'];


                $response[] = array(
                    "username" => $username,
                    "first_name" => $first_name,
                    "last_name" => $last_name,
                    "phone" => $phone,
                    "email" => $email,            
                );
            }
            echo json_encode($response);
}



