<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM storage_plan  ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) > 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                                                                                                                                                                                                                        
                                 <td data-id2="' . $row["id"] . '" >' . $row["packageType"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["code"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["detail"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["price"] . '</td>                                                                      
                                 <td data-id6="' . $row["id"] . '" >' . $row["duration"] . '</td>                                                                      
                                 <td data-id7="' . $row["id"] . '" >' . $row["capacity"] . '</td>                                                                      
                                 <td data-id8="' . $row["id"] . '" >' . $row["support"] . '</td>                                                                      
                                 <td data-id9="' . $row["id"] . '" >' . $row["delivery"] . '</td>                                                                                       
                                 <td data-id10="' . $row["id"] . '" >' . $row["refund"] . '</td>                                                                                       
                                 <td> <button type="button" class="btn btn-primary edit-storage fa fa-edit" data-toggle="modal" data-target="#editStorage"></button></td>  
                                 <td> <button type="button" id="delete-storage" name="delete-storage" data-id1="' . $row["id"] . '" class="btn btn-danger delete-storage fa fa-trash"></button></td>  
                            </tr>  
                       ';
                    
                }
        echo $output;
        }