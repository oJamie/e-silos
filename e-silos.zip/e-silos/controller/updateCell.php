<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

//        if (isset($_POST['updateStorage'])){
           $cellName = $_POST['cell_name'];
           $cellID = $_POST['cell_id'];
           $country = $_POST['country'];
           $region = $_POST['region'];
           $city = $_POST['city'];
           $coordinator = $_POST['coordinator'];

            $sql = " UPDATE cell SET cell_name = '$cellName', cell_id = '$cellID', country = '$country', region = '$region', city = '$city', coordinator = '$coordinator' ";
            $result = mysqli_query($connection_ref, $sql);

                if ($result == TRUE) {
                    echo "Cell Information Updated Successfully";                    
//                    echo $sql;
                }
                else {
                    echo "Error Updating Cell Information " . $connection_ref->error;
                }

$connection_ref->close();
    