<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM coordinator";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                                                                                                                    
                                 <td data-id2="' . $row["id"] . '" >' . $row["username"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["first_name"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["last_name"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["phone"] . '</td>                                                                      
                                 <td data-id6="' . $row["id"] . '" >' . $row["email"] . '</td>                                                                      
                                 <td data-id7="' . $row["id"] . '" >' . $row["country"] . '</td>                                                                      
                                 <td data-id8="' . $row["id"] . '" >' . $row["region"] . '</td>                                                                      
                                 <td data-id9="' . $row["id"] . '" >' . $row["city"] . '</td>                                                                                       
                                 <td> <button type="button" id="edit-coordinator" data-id="' . $row["id"] . '"  class="btn btn-primary edit-coordinator fa fa-edit" data-toggle="modal" data-target="#editCordinator"></button></td>  
                                 <td> <button type="button" id="delete-coordinator" name="delete-coordinator" data-id1="' . $row["id"] . '" data-id2 = '.$row['username'].' class="btn btn-danger delete-coordinator fa fa-trash"></button></td>  
                            </tr>  
                       ';
                    
                }
        echo $output;
        }