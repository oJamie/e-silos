<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();              


$connection_ref->close();
