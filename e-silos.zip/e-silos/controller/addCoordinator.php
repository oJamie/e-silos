<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        $username = $_POST['username'];
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $phone = $_POST['phone'];
        $category = $_POST['category'];
        $email = $_POST['email'];
        $country = $_POST['country'];
        $region = $_POST['region'];
        $city = $_POST['city'];
        $pass = md5($_POST['password']);
        
       
            $sql = " INSERT INTO coordinator (username, first_name, last_name, phone, email, country, region, city)"
                    . "VALUES ('$username','$first_name','$last_name','$phone','$email','$country','$region','$city');";
            $sql .= " INSERT INTO users (username, password, category)"
                    . "VALUES ('$username', '$pass', '$category')";
            $result = mysqli_multi_query($connection_ref, $sql);

            if ($result == TRUE) {
                echo "Co-ordinator Added Successfully";
            } else {
                echo "Error Adding Co-ordinator  " . $connection_ref->error;
            }
//        }

$connection_ref->close();
    