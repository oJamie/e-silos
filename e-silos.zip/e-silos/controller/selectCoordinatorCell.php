<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $sql = "SELECT * FROM user_cell";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {   
//            echo $_SESSION['username'];
                while ($row = mysqli_fetch_array($result)) {                    
                    echo "<span class='w3-text-purple w3-large'>".$row['username'].": </span>". "<span>" .$row['message'] ."</span>". "<br>";
                    echo "<small class='w3-small'>" .$row['time'] . '</small>';
                    echo "<br>";
                    echo "<br>";
                }
//        echo $output;
        }