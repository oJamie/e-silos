<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        if (isset($_POST['updateStorage'])){
            $packageType = $_POST['packageType'];
            $code = $_POST['code'];
            $detail = $_POST['detail'];
            $price = $_POST['price'];
            $duration = $_POST['duration'];
            $capacity = $_POST['capacity'];
            $support = $_POST['support'];
            $delivery = $_POST['delivery'];
            $refund = $_POST['refund'];


                $sql = " UPDATE storage_plan SET packageType = '$packageType', code = '$code', detail = '$detail', price = '$price', duration = '$duration', capacity = '$capacity', support = '$support', delivery = '$delivery', refund = '$refund'";
                $result = mysqli_query($connection_ref, $sql);

                if ($result == TRUE) {
                    echo "Storage Updated Successfully";
                } else {
                    echo "Error Updating Storage  " . $connection_ref->error;
                }
        }
//        }

$connection_ref->close();
    