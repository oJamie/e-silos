<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        $notification_type = $_POST['notification_type'];
        $notification_message = $_POST['notification_message'];
        $category = $_POST['category'];       
       
            $sql = " INSERT INTO notification (notification_type, notification_message, category)"
                    . "VALUES ('$notification_type','$notification_message','$category')";
            $result = mysqli_query($connection_ref, $sql);

            if ($result == TRUE) {
                echo "Notification Uploaded Successfully";
            } else {
                echo "Uploaded Unsuccessful  " . $connection_ref->error;
            }
//        }

$connection_ref->close();
    