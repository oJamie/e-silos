<?php

require_once '../config/db_config.php';
session_start();



        $escaped_username = $_POST['username'];
        $pass = md5($_POST['password']);
        $conpass = md5($_POST['con_password']);
        $category = $_POST['category'];        
        
//        echo $category;
        
        global $connection;
        
            $select = "SELECT username FROM users ";
            $result = mysqli_query($connection, $select);
            
           
            if (mysqli_num_rows($result) >= 0) {
                $row = mysqli_fetch_assoc($result);
                
                if ($row['username'] == $escaped_username){
                    echo "Username taken";
                } 
            else{
                
                if ($pass != $conpass){
                    echo "Password do not match";
                }
                else {


                    $sql = "  INSERT INTO users(username,password,category) VALUES('$escaped_username','$pass', '$category');";
                    $sql .= " INSERT INTO registration (username, category) VALUES('$escaped_username', '$category')";
                   
                    $query = mysqli_multi_query($connection, $sql);

                    if (!$query) {
                       echo 'Failed '. " ". mysqli_error($connection);

                    } else {
                       echo "Registration Successful, Continue to login";
                    }
            }
        }
    }
?>
