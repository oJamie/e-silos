<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

//        if (isset($_POST['updateStorage'])){
            $username = $_POST['username'];
            $first_name = $_POST['first_name'];
            $last_name = $_POST['last_name'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];            


            $sql = " UPDATE coordinator SET username = '$username', first_name = '$first_name', last_name = '$last_name', phone = '$phone', email = '$email'    ";
            $result = mysqli_query($connection_ref, $sql);

                if ($result == TRUE) {
                    echo "Coordinator Information Updated Successfully";                    
//                    echo $sql;
                }
                else {
                    echo "Error Updating Coordinator Information " . $connection_ref->error;
                }

$connection_ref->close();
    