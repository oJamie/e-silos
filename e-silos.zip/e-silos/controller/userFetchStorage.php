<?php

session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();
//session_start();
//    $id = $_POST['id'];
    $user = $_SESSION['username'];
//    
    $output = '';

    $select_data = "SELECT * FROM user_storage WHERE username = '$user'";
    $result = mysqli_query($connection_ref, $select_data);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)):
                    
                    $output .= '
                                <tr>
                                    <td data-id2="' . $row["id"] . '" >' . $row["packageType"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["code"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["detial"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["price"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["duration"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["capacity"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["support"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["delivery"] . '</td>   
                                    <td data-id2="' . $row["id"] . '" >' . $row["refund"] . '</td>                                        
                                </tr>
                               ';                    
                
                echo  $output;
                
                endwhile;
                
    }
    else {
        echo "0 results";
    }

