<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        $cellName = $_POST['cell_name'];
        $cellID = $_POST['cell_id'];
        $country = $_POST['country'];
        $region = $_POST['region'];
        $city = $_POST['city'];
        $coordinator = $_POST['coordinator'];
        
        $selectCell = "SELECT coordinator from cell";
        $resultCell = mysqli_query($connection_ref, $selectCell);
        
         if (mysqli_num_rows($resultCell) >= 0) {            
            $row = mysqli_fetch_array($resultCell);
            $row['coordinator'];
            
            if ($coordinator != $row['coordinator']){

                $sql = " INSERT INTO cell (cell_name, cell_id, country, region, city, coordinator)"
                            . "VALUES ('$cellName','$cellID','$country','$region','$city','$coordinator')";
                $result = mysqli_query($connection_ref, $sql);

                    if ($result) {
                        echo "Cell Added Successfully";
                    } else {
                        echo "Error Adding Successfully  " . $connection_ref->error;
                    }
            } else {
                echo "Coordinator already allocated to a cell, choose another location";
            }
         }
//        }

$connection_ref->close();
    