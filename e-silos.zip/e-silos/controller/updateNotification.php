<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

//        if (isset($_POST['updateStorage'])){
            
            $packageType = $_POST['notification_type'];
            $code = $_POST['notification_message'];
            $detail = $_POST['category'];
            

            $sql = " UPDATE notification SET notification_type = '$packageType', notification_message = '$code', category = '$detail' ";
            $result = mysqli_query($connection_ref, $sql);

                if ($result == TRUE) {
                    echo " Updated Successfully";                    
                }
                else {
                    echo "Error Updating " .$connection_ref->error;
                }

$connection_ref->close();
    