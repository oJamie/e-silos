<?php

include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $id = trim($_POST['id']);
    $username = trim($_POST['id2']);
    
    $sql = "DELETE FROM user_cell WHERE username = '$username' AND id = '$id' ";
    echo $_POST['id'];
    if (mysqli_query($connection_ref, $sql)) {
        echo 'Data Deleted';
    }  else{
        echo "Error".$connection_ref->error;
    }


