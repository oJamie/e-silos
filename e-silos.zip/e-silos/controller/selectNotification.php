<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM notification  ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                                                                                                    
                                 <td data-id3="' . $row["id"] . '" >' . $row["notification_type"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["notification_message"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["category"] . '</td>                                                                                                                                                                                            
                                 <td> <button type="button" data-id="'. $row['id'] .'" class="btn btn-primary edit-notification fa fa-edit" id="edit-notification" data-toggle="modal" data-target="#editNotification"></button></td>  
                                 <td> <button type="button" id="delete-notification" name="delete-notification" data-id1="' . $row["id"] . '" class="btn btn-danger delete-notification fa fa-trash"></button></td>  
                            </tr>  
                       ';
                    
                }
        echo $output;
        }