<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        $category = $_POST['category'];       
        $subject = $_POST['subject'];
        $message = $_POST['message'];
       
            $sql = " INSERT INTO inbox (category, subject, message) VALUES ('$category','$subject','$message')";
            $result = mysqli_query($connection_ref, $sql);

            if ($result == TRUE) {
                echo "Message sent";
            } else {
                echo "Message not sent  " . $connection_ref->error;
            }
//        }

$connection_ref->close();
    