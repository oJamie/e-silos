<?php

include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $id  = trim($_POST['id']);
    $id2  = trim($_POST['id2']);
    $sql = "DELETE FROM coordinator WHERE id = '$id' ";
    $result = mysqli_query($connection_ref, $sql);
    
    $sql2 = "DELETE FROM users WHERE username = '$id2'  ";
    $result2 = mysqli_query($connection_ref, $sql2);

    if ($result == TRUE) {
        echo 'Data Deleted';
    }
    else if ($result2 == TRUE){        
        echo 'Data Deleted';
    } 
    else if ($result2 == FALSE){
        echo 'Error';
    }
    else{
        echo "Error".$connection_ref->error;
    }


