<?php

include('../config/db_config.php');
require '../trader/session.php';

    $message = $_POST['message'];    
//    $message = md5($_POST['message']);
    
    
    $sql = " INSERT INTO chat (username, message) VALUES ('{$_SESSION['username']}', '$message')";
    $result = mysqli_query($connection, $sql);
//    echo $message;

    if ($result == TRUE) {
//                    echo "Cell Added Successfully";
    }
    else {
        echo "Message not sent  " . $connection->error;
    }
//        }

$connection->close();
