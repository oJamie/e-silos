<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * "
         . "FROM registration WHERE category = 'farmer'"
            . " ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) > 0) {            
                while ($row = mysqli_fetch_assoc($result)):
                    $output .= '  
                            <tr>                                   
                                 <td data-id2="' . $row["id"] . '" >' . $row["username"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["first_name"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["last_name"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["phone"] . '</td>                                                                       
                                 <td data-id6="' . $row["id"] . '" >' . $row["email"] . '</td>                                                                                                                                                                               
                                 <td> <button type="button" id="" name="add_to_cell" data-id1="' . $row["id"] . '" class="btn btn-primary add_to_cell fa fa-plus" data-toggle="modal" data-target="#addCell"> To Cell</button></td>                                     
                            </tr>  
                       ';
                    
        echo $output;
                endwhile;
        }