<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM inbox WHERE category = 'coordinator'  ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_assoc($result)) {
                    $output .= '  
                            <tr> 
                                <td><input type="checkbox" /></td>                                                                    
                                 <td data-id3="' . $row["id"] . '" >' . $row["subject"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["message"] . '</td>                                                                                                                                                                                              
                                   
                            </tr>  
                       ';
                    
                }
        echo $output;
        }