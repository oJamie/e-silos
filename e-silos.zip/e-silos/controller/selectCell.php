<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM cell  ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                                                                                                                                                                                                                          
                                 <td data-id2="' . $row["id"] . '" >' . $row["cell_name"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["cell_id"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["country"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["region"] . '</td>                                                                      
                                 <td data-id6="' . $row["id"] . '" >' . $row["city"] . '</td>                                                                      
                                 <td data-id7="' . $row["id"] . '" >' . $row["coordinator"] . '</td>                                                                      
                                 <td> <button type="button" id="delete-cell" name="delete-cell" data-id1="' . $row["id"] . '" class="btn btn-danger delete-cell fa fa-trash"></button></td>  
                            </tr>  
                       ';
                    
                }
        echo $output;
        }
        
//        <td> <button type="button" id="edit-cell" name="edit-cell" data-id="' . $row["id"] . '" class="btn btn-primary edit-cell fa fa-edit" data-toggle="modal" data-target="#editCell"></button></td>  
                                