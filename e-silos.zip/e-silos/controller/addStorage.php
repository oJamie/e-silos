<?php

include('../Admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();

        $packageType = $_POST['packageType'];
        $code = $_POST['code'];
        $detail = $_POST['detail'];
        $price = $_POST['price'];
        $duration = $_POST['duration'];
        $capacity = $_POST['capacity'];
        $support = $_POST['support'];
        $delivery = $_POST['delivery'];
        $refund = $_POST['refund'];
      
       
            $sql = " INSERT INTO storage_plan(packageType,code,detail,price,duration,capacity,support,delivery,refund)"
                    . "VALUES ('$packageType','$code','$detail','$price','$duration','$capacity','$support','$delivery','$refund')";
            $result = mysqli_query($connection_ref, $sql);

            if ($result == TRUE) {
                echo "Storage Added Successfully";
            } else {
                echo "Error Adding Storage  " . $connection_ref->error;
            }
//        }

$connection_ref->close();
    