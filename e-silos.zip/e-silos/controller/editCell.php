<?php

include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $id  = $_POST['id'];

    $sql = "SELECT * FROM cell WHERE id = '$id' ";
        $result = mysqli_query($connection_ref, $sql);        

            //echo 'here';
            $response = array();
        if (mysqli_num_rows($result) >= 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $cell_name = $row['cell_name'];
                $cell_id = $row['cell_id'];
                $country = $row['country'];
                $region = $row['region'];
                $city = $row['city'];
                $coordinator = $row['coordinator'];


                $response[] = array(
                    "cell_name" => $cell_name,
                    "cell_id" => $cell_id,
                    "country" => $country,
                    "region" => $region,
                    "city" => $city,            
                    "coordinator" => $coordinator,            
                );
            }
            echo json_encode($response);
}



