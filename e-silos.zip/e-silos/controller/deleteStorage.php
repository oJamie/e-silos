<?php

include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    $sql = "DELETE FROM storage_plan WHERE id = ".$_POST['id']." ";
    //echo 'here';
    if (mysqli_query($connection_ref, $sql)) {
        echo 'Data Deleted';
    }  else{
        echo "Error".$connection_ref->error;
    }


