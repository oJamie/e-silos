<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

  $output = '';
  
    $sql = "SELECT * FROM market  ";
    $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) >= 0) {            
                while ($row = mysqli_fetch_array($result)) {
                    $output .= '  
                            <tr>                                                                                                                                    
                                 <td data-id2="' . $row["id"] . '" >' . $row["prod_name"] . '</td>                                                                      
                                 <td data-id3="' . $row["id"] . '" >' . $row["description"] . '</td>                                                                      
                                 <td data-id4="' . $row["id"] . '" >' . $row["city"] . '</td>                                                                      
                                 <td data-id5="' . $row["id"] . '" >' . $row["acc_type"] . '</td>                                                                      
                                 <td data-id6="' . $row["id"] . '" >' . $row["acc_name"] . '</td>                                                                      
                                 <td data-id7="' . $row["id"] . '" >' . $row["acc_number"] . '</td>                                                                      
                                 <td data-id8="' . $row["id"] . '" >' . $row["amount"] . '</td>                                                                      
                                 <td data-id9="' . $row["id"] . '" >' . $row["file"] . '</td>                                                                                       
                                 <td> <button type="button" id="edit-add" name="edit-add" data-id0="' . $row["id"] . '" class="btn btn-primary edit fa fa-edit" data-toggle="modal" data-target="#editAD"></button></td>  
                                 <td> <button type="button" id="delete-add" name="delete-add" data-id1="' . $row["id"] . '" class="btn btn-danger delete-add fa fa-trash"></button></td>  
                            </tr>  
                       ';
                    
                }
        echo $output;
        }