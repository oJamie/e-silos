<?php
	session_start();
	if(isset($_SESSION['login_user'])){
            header("location:login/index.php");     
        }
        else
        {
//          $password = "";        
?>
<!DOCTYPE html>
<html>
<head>
	<title> e-silos | Admin:: Login</title>
        <!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Garden Care web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
          <!--<link rel="stylesheet" href="css/sweetalert.css"/>-->
        <link rel="Shortcut Icon" type="image/x-icon" href="../../images/images.png"/>
	<link rel="stylesheet" href="../assets/css/bootstrap.css">
	<script src="../assets/js/jquery.min.js"></script>
	<link rel="stylesheet" href="../assets/css/main.css">
	<link rel="stylesheet" href="../assets/css/login.css">
	<link rel="stylesheet" href="../../css/w3.css" type="text/css" media="all">
	<!-- Bootstrap-Core-CSS and W3-css -->
        <link rel="stylesheet" href="../../css/style3.css" type="text/css"/>                    
	<link rel="stylesheet" href="../../css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<link rel="stylesheet" href="../../css/font-awesome.css" type="text/css" media="all">
	<!-- Font-Awesome-Icons-CSS -->
</head>
<body >
	<div id="main_login">
		<div class="row">
			<div class="col-md-2">
			</div>
			<div class="col-md-4 cmptr">
				<img src="../assets/img/b.png" class="pull-left" caption="d">
				<div class="panel pull-right pnldef lft">
					<sm>a</sm>
					<sm>d</sm>						
					<sm>m</sm>						
					<sm>i</sm>
					<!--<sm class="btn-info">F12</sm>-->						
					<sm>n</sm>						
					<sm>i</sm>						
					<sm>s</sm>						
					<sm>t</sm>						
					<sm>r</sm>
					<sm>a</sm>
					<sm>t</sm>						
					<sm>o</sm>						
					<sm>r</sm>						
					<sm>h</sm>
					<sm>?</sm>
					<sm class="btn-danger">del</sm>						
					<br>
					<sm>a</sm>
					<sm>d</sm>						
					<sm>d</sm>						
					<sm>+</sm>
					<sm class="btn-info">add</sm>						
					<sm>@</sm>						
					<sm>del</sm>						
					<sm>F8</sm>						
					<sm>@</sm>						
					<sm>n</sm>
					<sm>j</sm>
					<br>
					<sm>a</sm>
					<sm>d</sm>						
					<sm>d</sm>						
					<sm>+</sm>
					<sm class="btn-primary">ins</sm>						
					<sm>@</sm>						
					<sm>@</sm>						
					<sm>n</sm>
					<sm>j</sm>
					<sm>del</sm>						
					<sm>F3</sm>						
					<sm>@</sm>						
					<sm>h</sm>
					<sm>?</sm>
					<sm class="btn-default">Home</sm>						
					<br>
					<sm>u</sm>						
					<sm>e</sm>						
					<sm>-</sm>						
					<sm>5</sm>
					<sm class="btn-success">l</sm>						
					<sm>p</sm>
					<sm>d</sm>						
					<sm>a</sm>						
					<sm>t</sm>
					<sm class="btn-warning">shift</sm>						
					<sm>a</sm>						
					<sm>t</sm>
					<sm>e</sm>						
					<sm>-</sm>						
					<sm>5</sm>
					<sm class="btn-success">enter</sm>						
					<br>
					<sm class="btn-success">ctrl</sm>						
					<sm class="glyphicon glyphicon-th-large"></sm>						
					<sm>alt</sm>
					<sm class="btn-primary">space</sm>						
					<sm>alt</sm>
					<sm class="glyphicon glyphicon-th-large"></sm>						
					<sm class="glyphicon glyphicon-list-alt"></sm>						
					<sm>ctrl</sm>						
				</div>
			</div>
			<div class="col-md-2">
			</div>
			<div class="col-md-4 w3-round-jumbo">
				<div class="col-md-8 lgdef">
					 <h1 class="w3l-logo2 w3-margin-top w3-padding-bottom w3-center w3-medium" >
                                            <a href="index.php"><i class="fa fa-envira" aria-hidden="true"></i>e-silos</a>
                                         </h1>      
                                    <hr>

                                    <form action="login.php" method="POST" autocomplete="off">
						<div class="input-group">
							<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span></span>
							<input type="text" id="name" name="username" placeholder="username" class="form-control"  value="admin">
						</div>
						<br>
						<div class="input-group">
							<span class="input-group-addon"><span class="glyphicon glyphicon-pencil"></span></span>
							<input type="password" id="password" name="password" placeholder="**********" class="form-control" value="admin" >
						</div><br>
						<div class="input-group">
							<input type='submit' name='submit' class="btn btn-info "  value="LOGIN">
						</div><br>
					</form>
                                    <div class="list-group text-left  " style="height: 230px">
<!-- 						<a  class="list-group-item text-success">e-silos ADMIN </a>
 						<a  class="list-group-item"><input type='hidden' value="">ADD NEW ADMINISTRATOR </a>
 						<a  class="list-group-item"><input type='hidden' value="">MANAGE USERS</a>
 						<a  class="list-group-item">VIEW ENTRIES </a>
 						<a  class="list-group-item">EDIT ENTRIES </a>
 						<a  class="list-group-item">DEACTIVATE ADMINISTRATED USERS </a>-->
 						
				</div>
			</div>
		</div>
	</div>
            <!--<h3 style="padding-top: 10px"> <a target=""  href="http://localhost/e-silos/index.php" class="fa fa-reply"> Main Page </a></h3>-->
	<script src="../assets/js/bootstrap.js"></script>
</body>
</html>
<?php
}
?>