<?php
require('login/session.php');
include('connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();
?>

<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>e-silos | Admin Dashboard</title>

        <link rel="icon" type="icon" href="../images/images.png"/>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="dist/css/sb-admin-2.css" rel="stylesheet">

        <!-- Morris Charts CSS -->
        <link href="vendor/morrisjs/morris.css" rel="stylesheet">
        <link href="../css/w3.css" rel="stylesheet">
        <link href="../css/style.css" rel="stylesheet">
        <link href="../css/datatables.min.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


    </head>

    <body>

        <div class="container w3-white w3-round" style="height: 800px; margin-top: 2%">
            <button class="btn btn-primary w3-right w3-margin-top">
                <span class="fa fa-arrow-left"> Back </span>
            </button>
            <br>
            <br>
            <hr>

            <div class="content">
                <form>
                    <div class="form-group">
                        <label for="type">Storage Type</label>
                        <input type="text" class="form-control" id="storageType" placeholder="Storage Type">                       
                    </div>                    
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Generate Code" aria-label="Recipient's username" aria-describedby="basic-addon2">                       
                        </div>
                        <div class="col">
                            <button class="btn btn-info" type="button">Generate Code</button>
                        </div>
                    </div>


                </form>
            </div>
        </div>



        <!-- jQuery -->
        <script src="vendor/jquery/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="vendor/metisMenu/metisMenu.min.js"></script>

        <!-- Morris Charts JavaScript -->
        <script src="vendor/raphael/raphael.min.js"></script>
        <script src="vendor/morrisjs/morris.min.js"></script>
        <script src="data/morris-data.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="dist/js/sb-admin-2.js"></script>
        <script src="../js/datatables.min.js"></script>
        <script src="../execution/generateCode.js"></script>

        <script>
            $('#storage_table').DataTable();

            $('#addSorage').click(function () {
                window.location = 'add_storage.php';
            });
        </script>

    </body>    