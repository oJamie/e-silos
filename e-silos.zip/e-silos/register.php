<!DOCTYPE html>
<html lang="en">

    <head>
        <title> e-silos </title>
        <!-- Meta tag Keywords -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Garden Care web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
              />
        <script type="application/x-javascript">
            addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
            }, false);

            function hideURLbar() {
            window.scrollTo(0, 1);
            }
        </script>
        <!--// Meta tag Keywords -->
        <!-- css files -->
        <link rel="icon" type="icon" href="images/images.png"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
        <link rel="stylesheet" href="css/w3.css" type="text/css" media="all">
        <!-- Bootstrap-Core-CSS and W3-css -->
        <link rel="stylesheet" href="css/style3.css" type="text/css"/>                    
        <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
        <!--<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />-->
        <!-- Style-CSS -->
        <link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">


    </head>

    <body>
        <!-- banner -->
        <!--<div class="banner">-->

        <!-- banner -->
        <div class="agileits_top_menu  w3-small">

            <div class="w3l_header_left ">
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Fiapre Sunyani, Ghana</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i> +(233) 554 228 890</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:enriqueoneil09@gmail.com">e-silos@gmail.com</a></li>
                </ul>
            </div>
            <div class="w3l_header_right">
                <div class="w3ls-social-icons text-left">
                    <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                    <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    <!--<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
                    <a class="linkedin" href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="agileits_w3layouts_banner_nav">
            <nav class="navbar navbar-default">
            </nav>

            <div class="clearfix"> </div>
        </div>


        <div class="jumbotron w3-card-4 w3-white" style=" width: 50%; margin-left: 25%; height: 600px; ">
            <form method="post" autocomplete="off" action="" >
                <h2 class="w3-center"> Register</h2>
                <hr>
                <div class="form-group">
                    <div class="input-group">
                        <select name="category" class="form-control" id="category" >
                            <option> --select category ---</option>
                            <option value="Farmer">Farmer</option>
                            <option value="Trader">Trader</option>
                        </select>
                    </div>
                </div> 
                <div class="form-group" id="otherDisplay" style="display: none">
                    <div class="input-group">
                        <span>Please Specify</span>
                        <input type="text" name="category" id="category" class="form-control required" placeholder="Category"  /> 
                    </div>
                </div>                                       
                <div class="form-group">
                    <div class="input-group">
                        <input type="text" name="username" id="username" class="form-control required" placeholder="username"  data-validation="alphanumeric" data-validation-allowing="-_" /> 
                    </div>
                </div>                                       
                <div class="form-group">
                    <div class="input-group">
                        <input type="password" name="password" id="password" class="form-control required" placeholder="Password"  data-validation="strength" data-validation-strength="8" />                    
                    </div>
                    <!--<span class="w3-left w3-text-grey w3-small">Note: We will send you a code to reset your password</span>-->
                </div> 
                <div class="form-group">
                    <div class="input-group">
                        <input type="password" name="con_password" id="con_password" class="form-control required" placeholder="Confirm Password" data-validation="strength" data-validation-strength="8"   />                    
                    </div>
                    <!--<span class="w3-left w3-text-grey w3-small">Note: We will send you a code to reset your password</span>-->
                </div> 


                <div class="form-group w3-right">
                    <div class="input-group ">
                        <input type="button" name="register" id="register" class="btn btn-primary" value="Register" />
                    </div>
                </div>  

                <br><br>
                <hr>
                <p class="w3-center">
                    Have an Account ? <br>
                    <a class="w3-text-green" href="index.php" id="login"> Login</a>
                </p>
                <!--<hr>-->
                <div class="form-group w3-center">
                    <!--<button class="btn btn-lg btn-sm" type="submit"> Return back </button>-->
                    <!--                        <a href="http://localhost/e-silos/reset.php">
                                                <span class=" fa fa-hand-o-right"> Forgot Passsword </span>
                                            </a>    -->
                </div>  
                <br>
            </form>
        </div>


    </div>


    <script type="text/javascript" lang="Javascript" src="js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" lang="Javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" lang="Javascript" src="js/myscript.js"></script>
    <script type="text/javascript" lang="Javascript" src="js/notify.min.js"></script>
    <script type="text/javascript" lang="Javascript" src="js/dropify.min.js"></script>
    <!--<script type="text/javascript" lang="Javascript" src="js/dropify.min.js"></script>-->
    <!--<script type="text/javascript" lang="Javascript" src="js/formValidation.js"></script>-->
    <script type="text/javascript" lang="Javascript" src="execution/registration.js"></script>
    <script type="text/javascript" lang="Javascript" src="js/jquery.form-validator.min.js"></script>
<!--        <script type="text/javascript" lang="Javascript" >
        $('document').ready(function (){
            $('#login').click(function(){
               location = 'http://localhost/e-silos/index.php';
               $('#signIn').show(0);
            });
        });
    </script>-->

    <script>
        $.validate({
        modules : 'security',
                onModulesLoaded : function() {
                var optionalConfig = {
                fontSize: '12pt',
                        padding: '4px',
                        bad : 'Very bad',
                        weak : 'Weak',
                        good : 'Good',
                        strong : 'Strong'
                        };
                        $('input[name="password"]').displayPasswordStrength(optionalConfig);
                        }
        });
        
//        function yesnoCheck(that) {
//            if (that.value == "other") {
////            alert("check");
//            var category = document.getElementById('category');
//            document.getElementById('other').value = category;
//            document.getElementById("otherDisplay").style.display = "block";
//            } else {
//                document.getElementById("otherDisplay").style.display = "none";
//            }
//        }
    </script>

</body>
</html>