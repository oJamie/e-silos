<?php

// Auth::logout();

        echo "<script>alert('You have been logged out. Good bye!')</script>";
        session_destroy();
        
        header('Location: index.php');
