<?php

    $host = "localhost";
    $user = 'root';
    $pass = '';
    $dbname = 'e-silos';
    
    $connection = mysqli_connect($host, $user, $pass, $dbname);
    if (!$connection){
        echo ' Not connected';
    } else {
//        echo 'ok';
    }
             
            ?>