$('document').ready(function (){
  

    $(document).on('click', '#addCell', function () {
        var id = $(this).data('id');
        var id2 = $(this).data('id2');
       
            $.ajax({
                url: "../controller/addToCell.php",
                method: "POST",
                data: {id: id, id2: id2},
                dataType: "text",
                success: function (data)
                {
//                    $('#addCell').attr('disabled', true);
//                    $('#removeCell').removeAttr('disabled');
//                      alert(data);
                }
            });            
    });

    $(document).on('click', '#removeCell', function () {
        var id = $(this).data("id");       
            $.ajax({
                url: "../controller/removeFromCell.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
//                    $('#add_cell').attr('enabled', 'enabled');
//                    $('#remove_cell').attr('disabled', 'disabled');
                      alert(data);
                }
            });        
    });



    
});

