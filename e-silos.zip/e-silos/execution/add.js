$('document').ready(function (){
     
   
    $(document).on('click', '#deleteAd', function () {
        var id = $(this).data('id');
        if (confirm("Are you sure you want to delete this?"))
        {
            console.log(id);
            $.ajax({
                url: "../controller/deleteAD.php",
                type: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });



    
});

