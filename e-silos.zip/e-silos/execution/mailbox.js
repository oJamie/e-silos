$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectMessage.php",
                method: "POST",
                success: function (data) {
                    $('#sentBody').html(data);
                }
            });
        }
    fetch_data();
    
    function fetch_data_inbox()
     {
            $.ajax({
                url: "../controller/selectMessage.php",
                method: "POST",
                success: function (data) {
                    $('#inboxBody').html(data);
                }
            });
        }
    fetch_data_inbox();
    
    function fetch_trader_inbox()
     {
            $.ajax({
                url: "../controller/fetch_trader_message.php",
                method: "POST",
                success: function (data) {
                    $('#traderInbox').html(data);
                }
            });
        }
    fetch_trader_inbox();
    function fetch_trader_inbox()
     {
            $.ajax({
                url: "../controller/fetch_cord_message.php",
                method: "POST",
                success: function (data) {
                    $('#cordInbox').html(data);
                }
            });
        }
    fetch_trader_inbox();

    $(document).on('click', '#sendMessage', function () {
        var category = $('#category').val();
        var subject = $('#subject').val();
        var message = $('#message').val();
//        var username = "$_SESSION['username']
               
        
        if (category === ""){
            alert('Username is Empty');
        }
        else if (subject === ""){
            alert('subject is empty');
        }
        else if (message === ""){
            alert('message is empty');
        }
        
        else{
            $.ajax({
                url: "../controller/composeMessage.php",
                method: "POST",
                data: {category: category, subject: subject, message: message},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    fetch_data_inbox();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '.delete-coordinator', function () {
        var id = $(this).data("id1");
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteCoordinator.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });



    
});

