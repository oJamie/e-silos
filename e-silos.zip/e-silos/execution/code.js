$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectCoordinator.php",
                method: "POST",
                success: function (data) {
                    $('#coordinator_body').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#sendCode', function () {
//        var code = $('#code').val();
        var phone = $('#phone').val();
        
//        if (code === ""){
//            alert('code is Empty');
//        }
        if (phone === ""){
            alert('phone is empty');
        }       
        else{
            $.ajax({
                url: "../controller/sms.php",
                method: "POST",
                data: { phone: phone},
                dataType: "text",
                success: function (data)
                {
                    alert(data);                    
                    location.reload();
                }
            });
        }    
    });

    
    
});

