$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectNotification.php",
                method: "POST",
                success: function (data) {
                    $('#notification_body').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#upload', function () {
        var notification_type = $('#notification_type').val();
        var notification_message = $('#notification_message').val();
        var category = $('#category').val();        
        
        if (notification_type === ""){
            alert('notification type is Empty');
        }
        else if (notification_message === ""){
            alert('notification message is empty');
        }
        else if (category === ""){
            alert('category is empty');
        }       
        else{
            $.ajax({
                url: "../controller/addNotification.php",
                method: "POST",
                data: {notification_type: notification_type, notification_message: notification_message, category: category},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '.delete-notification', function () {
        var id = $(this).data("id1");
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteNotification.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });
    
    
    $(document).on('click', '.edit-notification', function () {
        var id = $(this).data("id");       
            $.ajax({
                url: "../controller/editNotification.php",
                method: "POST",
                data: {id: id},
                dataType: "json",
                success: function (data) {
                    for(var i = 0; i < data.length; i++){
                        $('#notification_type1').val(data[i]['notification_type']);
                        $('#notification_message1').val(data[i]['notification_message']);
                        $('#category1').val(data[i]['category']);                                               
                    }
                }
            });
        
    });
    $(document).on('click', '#update-notification', function () {   
        
        var notification_type = $('#notification_type1').val();
        var notification_message = $('#notification_message1').val();
        var category = $('#category1').val();                     
        
            $.ajax({
                url: "../controller/updateNotification.php",
                method: "POST",
                data: {notification_type: notification_type, notification_message: notification_message, category: category},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    fetch_data();
                    location.reload();
                    
                }
            });
        
    });





    
});

