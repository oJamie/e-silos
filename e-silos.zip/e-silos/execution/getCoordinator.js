$(document).ready(function (){
   
    $("#city").change(function (e) {
        $.post("../location_control/get_coordinator.php",
                {
                    city: $(this).val()
                },
                function (data) {
                    console.log(data);
                    $("#coordinator").html(data);
                });
    });

    
});