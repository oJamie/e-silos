$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectCoordinator.php",
                type: "POST",
                success: function (data) {
                    $('#coordinator_body').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#add-coordinator', function () {
        var username = $('#username').val();
        var first_name = $('#first_name').val();
        var last_name = $('#last_name').val();
        var phone = $('#phone').val();
        var category = $('#category').val();
        var email = $('#email').val();
        var country = $('#country').val();
        var region = $('#region').val();
        var city = $('#city').val();
        var password = $('#password').val();        
        
        if (username === ""){
            alert('Username is Empty');
        }
        else if (first_name === ""){
            alert('first name is empty');
        }
        else if (last_name === ""){
            alert('last name is empty');
        }
        else if (phone === ""){
            alert('phone is empty');
        }
        else if (email === ""){
           alert('email is empty'); 
        }
        else if (country === ""){
           alert('country is empty'); 
        }
        else if (region === ""){
            alert('region is empty');
        }
        else if (city === ""){
            alert('city is empty');
        }
        else if (password === ""){
            alert('password is empty');
        }
        else{
            $.ajax({
                url: "../controller/addCoordinator.php",
                method: "POST",
                data: {username: username, first_name: first_name, last_name: last_name, phone: phone, category: category, email: email, country: country, region: region, city: city, password: password},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '.delete-coordinator', function () {
        var id = $(this).data("id1");
        var id2 = $(this).data("id2");
//        console.log(id2);
//        console.log(id);
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteCoordinator.php",
                method: "POST",
                data: {id: id, id2: id2},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });
    
    $(document).on('click', '.edit-coordinator', function () {
        var id = $(this).data("id");       
            $.ajax({
                url: "../controller/editCoordinator.php",
                method: "POST",
                data: {id: id},
                dataType: "json",
                success: function (data) {
//                    console.log(data)
                    for(var i = 0; i < data.length; i++){
//                        document.getElementById('username').value = data[i]['username'];
                        $('#username1').val(data[i]['username']);
                        $('#first_name1').val(data[i]['first_name']);
                        $('#last_name1').val(data[i]['last_name']);
                        $('#phone1').val(data[i]['phone']);
                        $('#email2').val(data[i]['email']);                       
                    }
                }
            });
        
    });
    $(document).on('click', '#update-coordinator', function () {
//        var id = $(this).data("id");        
        var username = $('#username1').val();
        var first_name = $('#first_name1').val();
        var last_name = $('#last_name1').val();
        var phone = $('#phone1').val();
        var email = $('#email2').val();           
        
        console.log(username);
        
            $.ajax({
                url: "../controller/updateCoordinator.php",
                method: "POST",
                data: {username: username, first_name: first_name, last_name: last_name, phone: phone, email: email},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    fetch_data();
                    location.reload();
                    
                }
            });
        
    });



    
});

