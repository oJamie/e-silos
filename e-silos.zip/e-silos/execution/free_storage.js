$(document).ready(function () {


    $('#freeTrial').click(function () {
        $.confirm({
            content: 'Are you sure you want to proceed with this option?',
            type: 'orange',
            typeAnimated: true,
            buttons: {
                Action: {
                    text: 'Yes',
                    keys: ['shift', 'alt'],
                    btnClass: 'btn-green',
                    action: function () {
                        var session_container = "$_SESSION['username']";

                        var package_type = $('#packageType').val();
                        var duration = $('#duration').val();                        
                        var price = $('#price').val();
                        var detail = $('#detail').val();
//                        var package_code = '7CxhwmC4AN7';
                        var support = '';
                        var delivery = 'NO';
                        var storage = '2 Slot';
                        var refund = 'NO';
                        var username = session_container;
                        $.ajax({
                            url: "../trader/execInsertStorage.php",
                            method: "POST",
                            data: {package_type: package_type, duration: duration, slot: slot, amount: amount, detail: detail, package_code: package_code, support: support, delivery: delivery, free_storage: free_storage, refund: refund, session_container: username},
                            dataType: "text",
                            success: function (data) {
                                $('#data_body').html(data);
                                window.location = "http://localhost/e-silos/trader/free_storagePlan.php";
                                fetch_storage();
                            }
                        });
                    }
                },
                close: {
                    text: 'Close',
                    btnClass: 'btn-red',
                    keys: ['close'],
                    action: function () {
                    }
                }
            }
        });
    });
    $('#buyNow').click(function () {
        $.confirm({
            content: 'Are you sure you want to proceed with this option?',
            type: 'orange',
            typeAnimated: true,
            buttons: {
                Action: {
                    text: 'Yes',
                    keys: ['shift', 'alt'],
                    btnClass: 'btn-green',
                    action: function () {
                        $.confirm({
                            type: 'green',
                            typeAnimated: true,
                            btnClass: 'btn-green',
                            content: 'Contact the coordinator on <a href="tel:0554228890"> Click me</a>'
                        });
                    }
                },
                close: {
                    text: 'Close',
                    btnClass: 'btn-red',
                    keys: ['close'],
                    action: function () {
                    }
                }
            }
        });
    });



    $('#powerUp').click(function () {
        var redirect = window.location = 'http://localhost/e-silos/trader/buy_storage.php';
        if ($('#freePackage').hide()) {
            redirect;
        }

    });
});


