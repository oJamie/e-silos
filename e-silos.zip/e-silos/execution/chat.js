$(document).ready(function (){
    
//       var message = $('#message').val();
       
    function fetch_message()
     {         
         var id = $('#chatBtn').data('id');
         console.log(id);
         
            $.ajax({
                url: "../controller/selectChat.php",
                type: "POST",
                data: {id1: id},
                success: function (response) {
                    $('#messageContainer').html(response);
                }
            });
        }
    fetch_message();
   
    $('#send_message').click(function (){
       var message = $('#message').val();
//        $('#message').val("");

       var prevMessage = $('#messageContainer').val();
       
        $('#messageContainer').html(prevMessage + "<br>" + message);
//sconsole.log(message);
           
          
       if (message === ""){
           alert('Message Empty');
       } 
       else {
           $.ajax({
                url: "../controller/chat.php",
                type: "POST",
                data: {message: message},
                dataType: "text",
                success: function (data)
                {
//                    alert(data);
                    fetch_message();
                    location.reload();
                },
                error: function(XMLHttpRequest, data) 
                { 
                    alert("Status: " + "Check user inputs");                    
                }
            });   
        }
    });    
});