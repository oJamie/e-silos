$('document').ready(function () {
    
   function fetch_data()
     {
            $.ajax({
                url: "../controller/selectUsers.php",
                method: "POST",
                success: function (data) {
                    $('.userTable').html(data);
                }
            });
        }
    fetch_data(); 
    
    $(document).on('click', '#delete-users', function () {
        var id = $(this).data("id");
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteUsers.php",
                type: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });

});