$('document').ready(function (){
  

    $(document).on('click', '#addToCell', function () {
        var id = $(this).data('id');
        var id2 = $(this).data('id2');
        
        console.log(id);
        console.log(id2);
        
        if (confirm("Are you sure you want to add this data to cell?"))
        {
            $.ajax({
                url: "../controller/addFarmerToCell.php",
                method: "POST",
                data: {id: id, id2: id2},
                dataType: "text",
                success: function (data)
                {
                    $('#addToCell').attr('disabled', true);
                    $('#removeCell').removeAttr('disabled');
                      alert(data);                     
                }
            }); 
        }    
    });

    $(document).on('click', '#removeCell', function () {
        var id = $(this).data("id");       
        var id2 = $(this).data("id2");       
            $.ajax({
                url: "../controller/removeFromCell.php",
                method: "POST",
                data: {id: id, id2: id2},
                dataType: "text",
                success: function (data) {
                    $('#add_cell').removeAttr('disabled');
                    $('#remove_cell').attr('disabled', true);
                      location.reload();
                        alert(data);
                }
            });        
    });



    
});

