$('document').ready(function () {
        
    $.get("../location_control/get_countries.php",
            function (data) {
                $("#country").html(data);
            });

    $("#country").change(function (e) {
        $.post("../location_control/get_regions.php",
                {
                    country: $(this).val()
                },
                function (data) {
                    $("#region").html(data);
                });
    });

    $("#region").change(function (e) {
        $.post("../location_control/get_cities.php",
                {
                    region: $(this).val()
                },
                function (data) {
                    $("#city").html(data);
                });
    });       

});