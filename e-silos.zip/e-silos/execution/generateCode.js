function randomStringToInput(clicked_element)
{
    var self = $(clicked_element);
    var random_string = generateRandomString(12);
    $('input[name=code]').val(random_string);
//    self.remove();
}
function generateRandomString(string_length)
{
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz0123456789';
    var string = '';
    for(var i = 0; i <= string_length; i++)
    {
        var rand = Math.round(Math.random() * (characters.length - 1));
        var character = characters.substr(rand, 1);
        string = string + character;
    }
    return string;
}
function randomStringToInput2(clicked_element)
{
    var self = $(clicked_element);
    var random_string = generateRandomString2(12);
    $('input[name=cell_id]').val(random_string);
//    self.remove();
}
function generateRandomString2(string_length)
{
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz0123456789';
    var string = '';
    for(var i = 0; i <= string_length; i++)
    {
        var rand = Math.round(Math.random() * (characters.length - 1));
        var character = characters.substr(rand, 1);
        string = string + character;
    }
    return string;
}