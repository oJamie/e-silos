$('document').ready(function () {

    $.ajax({
        url: "../controller/userfetchStorage.php",
        type: "POST",
        success: function (data) {
            $('.storageBody').html(data);
        }
    });

})