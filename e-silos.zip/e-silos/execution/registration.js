$(document).ready(function () {
    
    $(document).on('click', '#register', function () {
        
        var username = $('#username').val();        
        var password = $('#password').val();
        var con_password = $('#con_password').val();
        var category = $('#category').val();
       
        if (username === "")
        {
            alert("Enter username");
            return false;
        }         
        else if (password === "")
        {
            alert("Enter Password");
            return false;
        } 
        else if (con_password === "")
        {
            alert("Enter Confirm Password");
            return false;
        } 
        else if (category === "")
        {
            alert("Enter Category ");
            return false;
        } else {
            console.log('i am here!');
            $.ajax({
                url: "controller/execRegistration.php",
                method: "POST",
                data: {username: username, password: password, category: category, con_password: con_password},
                dataType: "text",
                success: function (data)
                {
                    alert(data); 
                    location.reload();
                },
                error: function(XMLHttpRequest, data) { 
                    alert("Status: " + "Check user inputs");                    
                }   
            });
        }
    });
    
    
    });

