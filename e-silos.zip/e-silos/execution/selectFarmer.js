$('document').ready(function () {
    
   function fetch_data()
     {
            $.ajax({
                url: "../controller/selectAllUsers.php",
                method: "POST",
                success: function (data) {
                    $('.userTable').html(data);
                }
            });
        }
    fetch_data(); 
    
    
});