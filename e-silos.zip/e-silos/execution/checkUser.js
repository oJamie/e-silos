$(document).ready(function () {

    $(document).on('click', '#buyNow', function () {
        var id = $(this).data("id");
        var id2 = $(this).data("id2");
        
        $.ajax({
            url: "../controller/checkStorage.php",
            method: "POST",
            data: {id: id, id2: id2},
            dataType: "text",
            success: function (data)
            {
                if (confirm(data) == 'Okay'){
                    location = "http://localhost/e-silos/farmer/storage.php";
                } else {
                    location = "http://localhost/e-silos/farmer/payPackage.php";
                }
            }

        });
    });
});