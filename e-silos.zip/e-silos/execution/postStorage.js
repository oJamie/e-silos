$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectStorage.php",
                type: "POST",
                success: function (data) {
//                    console.log('hey');
                    $('.storage_bodyTable').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#saveStorage', function () {

       var packageType = $('#packageType').val();
       var code = $('#code').val();
       var detail = $('#detail').val();
       var price = $('#price').val();
       var duration = $('#duration').val();
       var capacity = $('#capacity').val();
       var support = $('#support').val();
       var delivery = $('#delivery').val();
       var refund = $('#refund').val();       
        
        if (packageType === ""){
            alert('packageType is Empty');
        }
        else if (code === ""){
            alert('first name is empty');
        }
        else if (detail === ""){
            alert('last name is empty');
        }
        else if (price === ""){
            alert('price is empty');
        }
        else if (duration === ""){
           alert('duration is empty'); 
        }
        else if (capacity === ""){
           alert('capacity is empty'); 
        }
        else if (support === ""){
            alert('support is empty');
        }
        else if (delivery === ""){
            alert('delivery is empty');
        }
        else if (refund === ""){
            alert('refund is empty');
        }
        else{
            $.ajax({
                url: "../controller/addStorage.php",
                type: "POST",
                data: {packageType: packageType, code: code, detail: detail, price: price, duration: duration, capacity: capacity, support: support, delivery: delivery, refund: refund},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '.delete-storage', function () {
        var id = $(this).data("id1");
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteStorage.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });



    
});


