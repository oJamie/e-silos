$('document').ready(function (){
  var profileData = new FormData();
  var attachData = new FormData();
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectCoordinator.php",
                method: "POST",
                success: function (data) {
                    $('#coordinator_body').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#updateProfile', function () {
        var username = $('#username').val();
        var firstName = $('#firstName').val();
        var lastName = $('#lastName').val();
        var phone = $('#phone').val();
        var email = $('#email').val();
    
        profileData.append('image', $('#image')[0].files[0]);
        uploadFilePicture();
//        console.log(image);
        
        if (username === ""){
            alert('Username is Empty');
        }
        else if (firstName === ""){
            alert('first name is empty');
        }
        else if (lastName === ""){
            alert('last name is empty');
        }
        else if (phone === ""){
            alert('phone is empty');
        }
        else if (email === ""){
           alert('email is empty'); 
        }
              
        else{
            $.ajax({
                url: "../controller/addProfile.php",
                method: "POST",
                data: {username: username, firstName: firstName, lastName: lastName, phone: phone, email: email},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '.delete-coordinator', function () {
        var id = $(this).data("id1");
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteCoordinator.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });



    
});

