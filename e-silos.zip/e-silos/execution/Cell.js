$('document').ready(function (){
  
    function fetch_data()
     {
            $.ajax({
                url: "../controller/selectCell.php",
                method: "POST",
                success: function (data) {
                    $('#cellTableBody').html(data);
                }
            });
        }
    fetch_data();

    $(document).on('click', '#add-cell', function () {
        var cell_name = $('#cell_name').val();
        var cell_id = $('#cell_id').val();
        var country = $('#country').val();
        var region = $('#region').val();
        var city = $('#city').val();
        var coordinator = $('#coordinator').val();
        
        
        if (cell_name === ""){
            alert('Username is Empty');
        }
        else if (cell_id === ""){
            alert('first name is empty');
        }
        else if (country === ""){
            alert('last name is empty');
        }
        else if (region === ""){
            alert('region is empty');
        }
        else if (city === ""){
           alert('city is empty'); 
        }
        else if (coordinator === ""){
           alert('country is empty'); 
        }       
        else{
            $.ajax({
                url: "../controller/addCell.php",
                method: "POST",
                data: {cell_name: cell_name, cell_id: cell_id, country: country, region: region, city: city, coordinator: coordinator},
                dataType: "text",
                success: function (data)
                {
                    alert(data);
                    fetch_data();
                    location.reload();
                }
            });
        }    
    });

    $(document).on('click', '#delete-cell', function () {
        var id = $(this).data("id1");
        console.log(id);
        if (confirm("Are you sure you want to delete this?"))
        {
            $.ajax({
                url: "../controller/deleteCell.php",
                method: "POST",
                data: {id: id},
                dataType: "text",
                success: function (data) {
                    alert(data);
                    location.reload();
                }
            });
        }
    });
//
////    edit coordinator
//    $(document).on('click', '.edit-cell', function () {
//        var id = $(this).data("id");       
//            $.ajax({
//                url: "../controller/editCell.php",
//                method: "POST",
//                data: {id: id},
//                dataType: "json",
//                success: function (data) {
////                    console.log(data)
//                    for(var i = 0; i < data.length; i++){
////                        document.getElementById('username').value = data[i]['username'];
//                        $('#cell_name1').val(data[i]['cell_name']);
//                        $('#cell_id1').val(data[i]['cell_id']);
//                        $('#country1').val(data[i]['country']);
//                        $('#region1').val(data[i]['region']);
//                        $('#city1').val(data[i]['city']);                       
//                        $('#coordinator1').val(data[i]['coordinator']);                       
//                    }
//                }
//            });
//        
//    });
//
////        update coordinator
//     $(document).on('click', '#update-cell', function () {
//        var cell_name = $('#cell_name1').val();
//        var cell_id = $('#cell_id1').val();
//        var country = $('#country1').val();
//        var region = $('#region1').val();
//        var city = $('#city1').val();           
//        var coordinator = $('#coordinator1').val();           
//        
//        console.log(cell_name);
//        
//            $.ajax({
//                url: "../controller/updateCell.php",
//                method: "POST",
//                data: {cell_name: cell_name, cell_id: cell_id, country: country, region: region, city: city, coordinator: coordinator},
//                dataType: "text",
//                success: function (data) {
//                    alert(data);
//                    fetch_data();
//                    location.reload();
//                    
//                }
//            });
//        
//    });


    
});

