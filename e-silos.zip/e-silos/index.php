<?php
//    include 'controllers/execLogin.php';
include 'config/db_config.php';
session_start();
$error_msg = '';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);


    $query  = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
//    $query  .= "SELECT * FROM coordinator WHERE username = '$username' ";
    $result = mysqli_query($connection, $query);
    
    if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            
            if ($row['category'] == 'Trader') {               
                $_SESSION['username'] = $username;
                $_SESSION['city'];
                $_SESSION['category'] = $row['category'];
                header('Location: http://localhost/e-silos/trader/index.php');
            } 
            if ($row['category'] == 'Farmer') {
                $_SESSION['category'] = $row['category'];
                $_SESSION['username'] = $username;
                header('Location: http://localhost/e-silos/farmer/index.php');
            } 
            if ($row['category'] == 'Coordinator') {
                
                $query  = "SELECT * FROM coordinator";
                $result = mysqli_query($connection, $query);
                if (mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_assoc($result);                        
                    $_SESSION['city'] = $row['city'];
                    
                    $_SESSION['category'] = $row['category'];
                    $_SESSION['username'] = $username;
                    header('Location: http://localhost/e-silos/coordinator/index.php');                                   
                } 
            } 
            else {
                    echo "<script> alert('Not a member'); </script>";
                }
        }
    
    } else {
        echo "<script> alert('Invalid Credentials, Please Check your details or Register an account'); </script>";
//        echo "";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <title> e-silos </title>
        <!-- Meta tag Keywords -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="Garden Care web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
              />
        <script type="application/x-javascript">
            addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
            }, false);

            function hideURLbar() {
            window.scrollTo(0, 1);
            }
        </script>
        <!--// Meta tag Keywords -->
        <!-- css files -->
        <link rel="icon" type="icon" href="images/images.png"/>
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css" media="all">
        <link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
        <link rel="stylesheet" href="css/w3.css" type="text/css" media="all">
        <!-- Bootstrap-Core-CSS and W3-css -->
        <!--<link rel="stylesheet" href="css/style3.css" type="text/css"/>-->                    
        <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
        <!--<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />-->
        <!-- Style-CSS -->
        <link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
        <!-- Font-Awesome-Icons-CSS -->
        <!--        <link href="css/nav.css" rel="stylesheet" type="text/css" media="all" />
                 For-Navigation-CSS 
                <link href="css/lsb.css" rel="stylesheet" type="text/css" media="all">-->


    </head>

    <body>
        <!-- banner -->
        <!--<div class="banner">-->

        <!-- banner -->
        <div class="agileits_top_menu  w3-small">

            <div class="w3l_header_left ">
                <ul>
                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> Fiapre Sunyani, Ghana</li>
                    <li><i class="fa fa-phone" aria-hidden="true"></i> +(233) 554 228 890</li>
                    <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a href="mailto:enriqueoneil09@gmail.com">e-silos@gmail.com</a></li>
                </ul>
            </div>
            <div class="w3l_header_right">
                <div class="w3ls-social-icons text-left">
                    <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                    <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                    <!--<a class="pinterest" href="#"><i class="fa fa-pinterest-p"></i></a>-->
                    <a class="linkedin" href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="agileits_w3layouts_banner_nav">
            <nav class="navbar navbar-default">
            </nav>

            <div class="clearfix"> </div>
        </div>


        <div class="banner">	
            <div class="container" >
                <ul class="agile_forms w3-padding-top">
                    <li><button class="btn btn-primary w3-hover-text-white" id="btnSign" > Sign In</button> </li>
                    <li><button class="btn btn-primary" onclick="location = 'register.php'" > Register </buton> </li>
                </ul>   
                <div class="w3-white" style="margin-top: 5%; width: 50%; margin-left: 25%; display: none" id="signIn">
                    <div class="panel-group">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="w3-center"> LOGIN </h3>
                            </div>
                            <div class="panel-body">
                                <form method="POST" action="index.php">
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </span>
                                        <input type="text" autofocus="" name="username" class="form-control" id="username" placeholder="Username" >
                                    </div>
                                    <div class="form-group input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-key"></i>
                                        </span>
                                        <input type="password" name="password" class="form-control" id="password" placeholder="Password" >
                                    </div>

                                    <button type="submit" class="btn btn-primary w3-right" name="login">Submit</button>
                                </form>
                            </div>
                        </div>    
                        <div class="panel-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal" onclick="document.getElementById('signIn').style.display = 'none'">Close</button>      
                        </div>
                    </div>
                </div>
            </div>
            <!--    end here-->
            <div class="w3layouts_banner_info">
                <section class="wrapper agileits-w3layouts_wrapper_home text-center w3-text-black">
                    <h1 class="w3l-logo"><a href="index.php">
                            <i class="fa fa-envira" aria-hidden="true"></i>e-silos</a></h1>
                            <!--<p class="w3-text-black"> Complete, Educative and Secured Electronic Warehouse for your Crops </p>-->
                    <div class="sentence w3-text-black" >
                        <div class="popEffect ">
                            <span>Enrich and Protect your Crops </span>
                            <span>Become well informed </span>
                            <span>Become Educated on Agriculture </span>                                            
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!-- //banner -->
        <!-- about -->
        <div class="about-w3l" id="about">
            <div class="container">
                <h2 class="title-w3l">About <span>Us</span></h2>
                <div class="col-md-3 col-xs-4 col-news-top  ">
                    <div class="date-in">
                        <img class="img-responsive mix-in " src="images/rainy.png" alt="" >
                    </div>
                    <div class="text-about ab-agile1">
                        <h4>Weather Information</h4>
                    </div>
                </div>
                <div class="col-md-3 col-xs-4 col-news-top">
                    <div class="date-in">
                        <img class="img-responsive mix-in" src="images/barn.png" alt="">
                    </div>
                    <div class="text-about ab-agile2">
                        <h4>Storage Facility</h4>
                    </div>
                </div>               
                <div class="col-md-3 col-xs-4 col-news-top">
                    <div class="date-in">
                        <img class="img-responsive mix-in" src="images/800px_COLOURBOX28500157.jpg" alt="">
                    </div>
                    <div class="text-about ab-agile4">
                        <h4>Online Store</h4>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <!-- //about -->
        <!-- middle -->
        <div class="projects">
            <div class="projects-grids">
                <div class="sreen-gallery-cursual">
                    <ul id="flexiselDemo1">
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/women-agriculture.jpg" alt="" />
                                    <div class="projects-grid-caption">

                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/15027414615.jpg" alt="" />
                                    <div class="projects-grid-caption">

                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/a-day-in-the-life-of-vietnamese-trader.jpg" alt="" />
                                    <div class="projects-grid-caption">

                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/farmingfuture_prod.jpg" alt="" />
                                    <div class="projects-grid-caption">
                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/ALR_Buffer.jpg" alt="" />
                                    <div class="projects-grid-caption">

                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item">
                                <div class="projects-agile-grid-info">
                                    <img src="images/s-in-a-Field.jpg" alt="" />
                                    <div class="projects-grid-caption">

                                        <h4>E-e-silos</h4>
                                        <p>ELECTRONIC WAREHOUSING</p>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- //middle -->
        <hr>
        <!-- services -->
        <div class="services" id="services">
            <div class="container">
                <h3 class="title-w3l">Our <span>Services</span></h3>
                <div class="col-md-4 w3ls_banner_bottom_grids">
                    <div class="agile_offer_grid">
                        <div class="agile_offer_grid_pos">
                            <p>1</p>
                        </div>
                        <div class="wthree_offer_grid1">                                            
                            <!--<img class="img-responsive w3-small" src="images/rainy.png" alt="">-->                                           
                            <h4>Weather Prediction</h4>
                            <p class="w3_agileits_service_para"> We provide exclusive weather information by using a predictive system to predict the weather condition for 7 days. </p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="agile_offer_grid">
                        <div class="agile_offer_grid_pos">
                            <p>2</p>
                        </div>
                        <div class="wthree_offer_grid1">
                            <h4>Health Information</h4>
                            <p class="w3_agileits_service_para">Duis autem vel eum iriure dolor in hendrerit in vulput ate velit esse molestie.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="agile_offer_grid">
                        <div class="agile_offer_grid_pos">
                            <p>3</p>
                        </div>
                        <div class="wthree_offer_grid1">
                            <h4>Crop Management and Maintenance</h4>
                            <p class="w3_agileits_service_para">Duis autem vel eum iriure dolor in hendrerit in vulput ate velit esse molestie.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
                <div class="col-md-4 w3ls_banner_bottom_grids w3l-plant">
                    <div class="agile_offer_grid w3l-grid-mk">
                        <div class="agile_offer_grid_pos">
                            <p>4</p>
                        </div>
                        <div class="wthree_offer_grid1">
                            <h4>E-Market</h4>
                            <p class="w3_agileits_service_para">Duis autem vel eum iriure dolor in hendrerit in vulput ate velit esse molestie.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>                   
                    <div class="agile_offer_grid">
                        <div class="agile_offer_grid_pos">
                            <p>5</p>
                        </div>
                        <div class="wthree_offer_grid1">
                            <h4>Education</h4>
                            <p class="w3_agileits_service_para">Duis autem vel eum iriure dolor in hendrerit in vulput ate velit esse molestie.</p>
                        </div>
                        <div class="clearfix"> </div>
                    </div>			
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <!-- //services -->

        <!-- password-script -->

        <!--password-script -->

        <!-- footer section -->
        <section class="footer-w3">
            <div class="container">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 footer-agile1" data-aos="zoom-in">
                    <h3>About Us</h3>
                    <p class="footer-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sed ligula ac metus finibus hendrerit sed at libero. Praesent
                        blandit dignissim elit, vel feugiat nulla porta a. Praesent tellus eros, consectetur quis tortor at, tempor varius quam.
                    </p>
                </div>


                <div class="clearfix"></div>
            </div>
        </section>
        <!-- //footer section -->

        <!-- js-scripts -->
        <!-- js -->
        <script type="text/javascript" src='js/jquery.min.js'></script>
        <script type="text/javascript" src='js/bootstrap.min.js'></script>
        <script type="text/javascript" src='js/myscript.js'></script>
        <script type="text/javascript" src='js/execRegistration.js'></script>
        <script type="text/javascript" src='js/notify.min.js'></script>

        <script type="text/javascript" lang="Javascript">
                                $(document).ready(function () {
                                    $('#btnSign').click(function () {
                                        $('#signIn').toggle(200);
                                    });

                                });
        </script>
    </body>

</html>