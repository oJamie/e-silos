<?php
session_start();// Starting Session

if(!isset($_SESSION['username']))
{
	header("location:../index.php");
}
else{
//    $_SESSION['login_user']=$username;
}
?>