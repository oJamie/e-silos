<?php
require('login/session.php');
include('connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase(); 
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>E-silos | Co-ordinator Dashboard</title>

    <link rel="icon" type="icon" href="../images/images.png"/>
    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="vendor/morrisjs/morris.css" rel="stylesheet">
    <link href="../css/w3.css" rel="stylesheet">
    <link href="../css/datatables.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    
</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">E-silos</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
                            <a href="profile.php"><i class="fa fa-user fa-fw"></i> Profile</a>
                        </li>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">                        
                        <li>
                            <a href="index.php"><i class="fa fa-home fa-fw"></i> Home</a>
                        </li>                        
                        <li>
                            <a href="users.php"><i class="fa fa-users fa-fw"></i> User</a>
                        </li>                      
<!--                        <li>
                            <a href="cell.php"><i class="fa fa-database fa-fw"></i> Cell </a>
                        </li>                                              -->
                        <li>
                            <a href="mailbox.php"><i class="fa fa-envelope fa-fw"></i> MailBox</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-cog fa-fw"></i> Settings<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">                               
                                <li>
                                    <a href="profile.php" class="fa fa-user"> Profile</a>
                                </li>
                                <li>
                                    <a href="../logout.php" class="fa fa-sign-out">Logout</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">MailBox</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>                               
                                <div class="col-xs-9 text-right">
                                    <div class="huge"> </div>
                                    <div>Users</div>
                                </div>
                            </div>
                        </div>
                        <a href="users.php">
                            <div class="panel-footer">
                                <span class="pull-left">View</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
<!--                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>                                
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                    
                                    </div>
                                    <div>Cell</div>
                                </div>
                            </div>
                        </div>
                        <a href="cell.php">
                            <div class="panel-footer">
                                <span class="pull-left">View </span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>-->
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-envelope fa-5x"></i>
                                </div>                                
                                <div class="col-xs-9 text-right">
                                    <div class="huge">                                              
                                    </div>
                                    <div>MailBox</div>
                                </div>
                            </div>
                        </div>
                        <a href="mailbox.php">
                            <div class="panel-footer">
                                <span class="pull-left">View </span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bell fa-5x"></i>
                                </div>                              
                                <div class="col-xs-9 text-right">
                                    <div class="huge">                                        
                                    </div>
                                    <div>Notification</div>
                                </div>
                            </div>
                        </div>
                        <a href="notification.php">
                            <div class="panel-footer">
                                <span class="pull-left">View</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>

                <!-- /.row -->
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#composeMess">
                    Compose <span class="fa fa-envelope"></span>
                </button> 
                <br>
                <!-- Modal -->
                <div class="modal fade" id="composeMess" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Compose Message</h5>                                
                            </div>
                            <div class="modal-body">
                                <form method="POST" action="" autocomplete="off">
                                    <fieldset>
                                        <div class="form-group">
                                            <select class="form-control " placeholder="Recipents Subject" name="category" id="category" type="text" >
                                                <option>--select category--</option>                                               
                                                <option value="Admin">Admin</option>
                                                <option value="Farmer">Farmer</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <input class="form-control subject" placeholder="Subject" name="subject" id="subject" type="text" />
                                        </div>                                                                                            
                                        <div class="form-group">
                                            <textarea class="form-control message" rows="7" placeholder="Message" name="message" id="message" type="text" ></textarea>
                                        </div>                                                                                            

                                        <a type="button" id="sendMessage" class="btn btn-success w3-right fa fa-envelope"> Send</a>
                                    </fieldset>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>                                
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                Lists
                            </div>
                            <div class="panel-body">                               
                                <ul class="list-group">                                                                         
                                    <a href="mailbox.php" >
                                        <li class="list-group-item">
                                            Inbox <span class="fa fa-arrow-right btn btn-circle w3-green w3-right"></span>
                                        </li>
                                    </a>                                         
                                </ul>

                            </div>
                            <!-- /.panel-body -->
                        </div>
                        <!-- /.panel -->
                    </div>

                    <!-- /.col-lg-8 -->
                    <div class="col-lg-8" >
                        <div class="content" >
                            <div class="panel panel-warning">
                                <div class="panel-heading">
                                    <h3> Inbox Message </h3>
                                </div>
                                <div class="panel-body">
                                    <form method="POST" action="" autocomplete="off">
                                        <fieldset>
                                            <div class="w3-content">
                                                <button type="button" class="btn btn-primary btn-circle ">
                                                    <i class="fa fa-refresh" id="refreshMail"></i>
                                                </button>                                                
                                                <hr>                                                
                                                <div class="w3-content">
                                                    <table class="table table-hover table-striped display" id="sentTable">
                                                        <tbody id="cordInbox" >

                                                        </tbody>
                                                    </table>
                                                    <!-- /.table -->
                                                </div>                                            
                                            </div>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>    


                    <!-- /#page-wrapper -->

                </div>
                <!-- /#wrapper -->

                <!-- jQuery -->
                <script src="vendor/jquery/jquery.min.js"></script>

                <!-- Bootstrap Core JavaScript -->
                <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

                <!-- Metis Menu Plugin JavaScript -->
                <script src="vendor/metisMenu/metisMenu.min.js"></script>

                <!-- Morris Charts JavaScript -->
                <script src="vendor/raphael/raphael.min.js"></script>
                <script src="vendor/morrisjs/morris.min.js"></script>
                <script src="data/morris-data.js"></script>

                <!-- Custom Theme JavaScript -->
                <script src="dist/js/sb-admin-2.js"></script>
                <script src="../js/myscript.js"></script>
                <script src="../js/bootstrap-notify.min.js"></script>
                <script src="../execution/mailbox.js"></script>

                   
                </body>

                </html>

