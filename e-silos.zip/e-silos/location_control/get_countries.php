<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

        $sql = "SELECT * FROM countries WHERE id = '83' ";
            $result = mysqli_query($connection_ref, $sql);        

        if (mysqli_num_rows($result) > 0) {
            
            echo '<option value="">--Select Country--</option>';
            while ($row = mysqli_fetch_assoc($result)) {
                 echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
            }
        }
?>


