<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

    if (!empty($_POST['city'])) {

        $city_id = $_POST['city'];
        
        $sql = "SELECT * FROM coordinator WHERE city = '$city_id' ";
        $result = mysqli_query($connection_ref, $sql);        

            if (mysqli_num_rows($result) > 0) {
                echo '<option value="">Select Co-ordinator</option>';
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo 'here';
                        echo '<option value="'.$row['first_name'] ." " .$row['last_name'].'">' . $row['first_name'] ." " .$row['last_name']. '</option>';
                    }
            }
    }
?>
