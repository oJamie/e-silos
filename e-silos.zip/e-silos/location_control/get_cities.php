<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

if(!empty($_POST['region'])){
	$region_id = $_POST['region'];
        
	$sql = "select * from cities where state_id = '$region_id'";
        $result = mysqli_query($connection_ref, $sql); 
        
	echo '<option value="">Select your city</option>';
	while($row = mysqli_fetch_assoc($result)){
		echo '<option value="' . $row['name'] .'">' .$row['name']. '</option>';
	}
}
?>
