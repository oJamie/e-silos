<?php
session_start();
include('../admin/connection.php');
$connection = new createConnection();    //created a new object
$connection_ref = $connection->connectToDatabase();    // $connection->selectDatabase();

//if (!empty($_POST['country'])) {
    $country_id = $_POST['country'];
    
    $sql = "SELECT * FROM states WHERE country_id = '83' ";
            $result = mysqli_query($connection_ref, $sql);        
//            echo 'here';
        if (mysqli_num_rows($result) > 0) {
            echo '<option value="">--Select Region--</option>';
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' .  $row['id']. " " .$row['name']. '">'  .$row['name']. '</option>';
                }
        }
//}
?>
<!--$sql = mysql_query("select * from states where country_id = '83'");
echo '<option value="">Select Region...</option>';
	while($row = mysql_fetch_assoc($sql)){
		if($row['id'] == $region){
			echo '<option selected value="'.$row['id'].'">'.$row['name'].'</option>';
		}else {
			echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
		}
	}-->

